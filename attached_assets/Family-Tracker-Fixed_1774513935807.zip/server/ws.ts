import { WebSocketServer, WebSocket } from "ws";
import type { Server as HttpServer } from "http";
import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.SESSION_SECRET || "fallback-secret-dev-only";

interface AuthPayload { profileId: string; familyId: string }
interface ClientInfo { ws: WebSocket; profileId: string; familyId: string }

const clients = new Map<WebSocket, ClientInfo>();

export function setupWebSocket(httpServer: HttpServer) {
  const wss = new WebSocketServer({ server: httpServer, path: "/ws" });

  wss.on("connection", (ws, req) => {
    // Authenticate via token in query string
    const url = new URL(req.url || "/", `http://${req.headers.host}`);
    const token = url.searchParams.get("token");
    if (!token) { ws.close(4001, "Missing token"); return; }

    let payload: AuthPayload;
    try {
      payload = jwt.verify(token, JWT_SECRET) as AuthPayload;
    } catch {
      ws.close(4001, "Invalid token"); return;
    }

    clients.set(ws, { ws, profileId: payload.profileId, familyId: payload.familyId });

    ws.on("close", () => { clients.delete(ws); });
    ws.on("error", () => { clients.delete(ws); });

    // Send confirmation
    ws.send(JSON.stringify({ type: "connected", profileId: payload.profileId }));
  });

  console.log("[WS] WebSocket server ready on /ws");
  return wss;
}

// Broadcast an event to all connected members of a family
export function broadcastToFamily(familyId: string, event: { type: string; [key: string]: any }, excludeProfileId?: string) {
  const payload = JSON.stringify(event);
  for (const [, client] of clients) {
    if (client.familyId === familyId && client.profileId !== excludeProfileId && client.ws.readyState === WebSocket.OPEN) {
      client.ws.send(payload);
    }
  }
}
