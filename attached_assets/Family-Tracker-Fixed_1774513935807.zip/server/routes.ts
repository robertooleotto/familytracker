import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { randomBytes, createHash, createCipheriv, createDecipheriv, scryptSync } from "crypto";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import cors from "cors";
import rateLimit from "express-rate-limit";
import { ObjectStorageService, ObjectNotFoundError } from "./replit_integrations/object_storage/objectStorage";
import * as tl from "./truelayer";
import { db } from "./db";
import { aiCache, aiInsights, profiles, expenses, shoppingItems, events, subscriptions, schoolConnections, schoolGrades, schoolAbsences, schoolHomework, schoolNotices, profileSettings, checkins, rewards, moodPhotos } from "@shared/schema";
import { classevivaLogin, classevivaGrades, classevivaAbsences, classevivaHomework, classevivaNotices } from "./school/classeviva";
import { argoLogin, argoGrades, argoAbsences, argoHomework, argoNotices } from "./school/argo";
import { eq, and, desc, inArray } from "drizzle-orm";
import { callClaude, callClaudeVision, parseJSON, getCached, saveInsight } from "./ai/aiEngine";
import { generateEveningSummary } from "./ai/features/eveningSummary";
import { generateSpendingForecast } from "./ai/features/spendingForecast";
import { detectAnomalies } from "./ai/features/anomalyDetector";
import { calculateHealthScore } from "./ai/features/healthScore";
import { generateStudyPlan } from "./ai/features/studyPlanner";
import { suggestShoppingItems } from "./ai/features/shoppingAI";
import { generateMemberNarrative } from "./ai/features/memberNarrative";
import { broadcastToFamily } from "./ws";

// Fix #3: Throw if JWT secret is not set in production
const JWT_SECRET = process.env.SESSION_SECRET || (() => {
  if (process.env.NODE_ENV === "production") throw new Error("SESSION_SECRET env var is required in production");
  console.warn("[SECURITY] Using fallback JWT secret — set SESSION_SECRET in production!");
  return "fallback-secret-dev-only";
})();

// Fix #2/#4: Encryption helpers for sensitive data at rest
const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || JWT_SECRET;
const ENC_ALGO = "aes-256-gcm";
function deriveKey(secret: string): Buffer { return scryptSync(secret, "ft-salt", 32); }
function encryptField(plaintext: string): string {
  const key = deriveKey(ENCRYPTION_KEY);
  const iv = randomBytes(16);
  const cipher = createCipheriv(ENC_ALGO, key, iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `${iv.toString("hex")}:${tag.toString("hex")}:${encrypted.toString("hex")}`;
}
function decryptField(ciphertext: string): string {
  try {
    const [ivHex, tagHex, encHex] = ciphertext.split(":");
    if (!ivHex || !tagHex || !encHex) return ciphertext; // not encrypted (legacy)
    const key = deriveKey(ENCRYPTION_KEY);
    const decipher = createDecipheriv(ENC_ALGO, key, Buffer.from(ivHex, "hex"));
    decipher.setAuthTag(Buffer.from(tagHex, "hex"));
    return decipher.update(Buffer.from(encHex, "hex")) + decipher.final("utf8");
  } catch { return ciphertext; } // fallback for unencrypted legacy data
}

function generateInviteCode(): string {
  return randomBytes(4).toString("hex").toUpperCase();
}
// Fix #1: Use bcrypt instead of SHA-256 for password hashing
async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}
async function verifyPassword(password: string, hash: string): Promise<boolean> {
  // Support legacy SHA-256 hashes during migration
  const legacyHash = createHash("sha256").update(password + JWT_SECRET).digest("hex");
  if (hash === legacyHash) return true;
  return bcrypt.compare(password, hash);
}
function generateToken(profileId: string, familyId: string): string {
  return jwt.sign({ profileId, familyId }, JWT_SECRET, { expiresIn: "30d" });
}
function verifyToken(token: string): { profileId: string; familyId: string } | null {
  try { return jwt.verify(token, JWT_SECRET) as any; } catch { return null; }
}
async function auth(req: Request, res: Response): Promise<{ profileId: string; familyId: string } | null> {
  const h = req.headers.authorization;
  if (!h?.startsWith("Bearer ")) { res.status(401).json({ message: "Unauthorized" }); return null; }
  const payload = verifyToken(h.slice(7));
  if (!payload) { res.status(401).json({ message: "Invalid token" }); return null; }
  return payload;
}
function safe(p: any) { const { passwordHash, ...rest } = p; return rest; }

// Fix #16: Input sanitization — strip HTML tags from user text inputs
function sanitize(input: string | null | undefined): string {
  if (!input) return "";
  return input.replace(/<[^>]*>/g, "").trim();
}
function sanitizeObj<T extends Record<string, any>>(obj: T, fields: string[]): T {
  const result = { ...obj };
  for (const f of fields) {
    if (typeof result[f] === "string") (result as any)[f] = sanitize(result[f]);
  }
  return result;
}

export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {
  // Fix #30: CORS for mobile app (Capacitor) support
  app.use(cors({ origin: true, credentials: true }));

  // Fix #15: Rate limiting
  const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 20, message: { message: "Troppi tentativi. Riprova tra qualche minuto." } });
  const apiLimiter = rateLimit({ windowMs: 60 * 1000, max: 120, message: { message: "Troppe richieste. Riprova tra poco." } });
  const aiLimiter = rateLimit({ windowMs: 60 * 1000, max: 10, message: { message: "Troppe richieste AI. Riprova tra poco." } });
  app.use("/api/auth", authLimiter);
  app.use("/api/ai", aiLimiter);
  app.use("/api", apiLimiter);

  // ─── AUTH ──────────────────────────────────────────────────────────────────
  // Helper: derive a unique username from email or name
  const makeUsername = async (base: string): Promise<string> => {
    const slug = base.toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 20) || "user";
    let candidate = slug;
    let n = 1;
    while (await storage.getProfileByUsername(candidate)) { candidate = `${slug}${n++}`; }
    return candidate;
  };

  app.post("/api/auth/register", async (req, res) => {
    try {
      const { firstName, lastName, email, password, familyName, role, colorHex } = req.body;
      if (!firstName || !lastName || !email || !password || !familyName)
        return res.status(400).json({ message: "Tutti i campi obbligatori sono richiesti" });
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
        return res.status(400).json({ message: "Indirizzo email non valido" });
      const existing = await storage.getProfileByEmail(email);
      if (existing) return res.status(409).json({ message: "Email già registrata" });
      const username = await makeUsername(email.split("@")[0]);
      const name = `${firstName} ${lastName}`;
      const family = await storage.createFamily({ name: familyName, inviteCode: generateInviteCode() });
      const profile = await storage.createProfile({ name, lastName, email, username, passwordHash: await hashPassword(password), familyId: family.id, role: role || "parent", colorHex: colorHex || "#3B82F6", uiMode: "full", avatarUrl: null, fcmToken: null, locationPaused: false });
      res.json({ profile: safe(profile), token: generateToken(profile.id, family.id) });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      if (!email || !password) return res.status(400).json({ message: "Credenziali mancanti" });
      // Accept login by email or username
      let profile = await storage.getProfileByEmail(email);
      if (!profile) profile = await storage.getProfileByUsername(email);
      if (!profile || !(await verifyPassword(password, profile.passwordHash)))
        return res.status(401).json({ message: "Email o password errata" });
      res.json({ profile: safe(profile), token: generateToken(profile.id, profile.familyId) });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.post("/api/auth/join", async (req, res) => {
    try {
      const { firstName, lastName, email, password, inviteCode, role, colorHex } = req.body;
      if (!firstName || !lastName || !password || !inviteCode)
        return res.status(400).json({ message: "Tutti i campi obbligatori sono richiesti" });
      const family = await storage.getFamilyByInviteCode(inviteCode.toUpperCase());
      if (!family) return res.status(404).json({ message: "Codice invito non valido" });
      if (email) {
        const existing = await storage.getProfileByEmail(email);
        if (existing) return res.status(409).json({ message: "Email già registrata" });
      }
      const baseSlug = email ? email.split("@")[0] : `${firstName}${lastName}`;
      const username = await makeUsername(baseSlug);
      const name = `${firstName} ${lastName}`;
      const profile = await storage.createProfile({ name, lastName, email: email || null, username, passwordHash: await hashPassword(password), familyId: family.id, role: role || "child", colorHex: colorHex || "#10B981", uiMode: "full", avatarUrl: null, fcmToken: null, locationPaused: false });
      res.json({ profile: safe(profile), token: generateToken(profile.id, family.id) });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── ONBOARDING ────────────────────────────────────────────────────────────
  app.post("/api/onboarding", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const {
        wakeTime, sleepTime, dinnerTime, occupation, whoShops, shoppingFrequency,
        hasPartner, kidsCount, kidsAges, hasPets, petTypes,
        homeType, vehicleCount, recurringDeadlines, activeSubscriptions,
        allergies, dietaryRestrictions, foodDislikes, foodLikes, whoCoooks,
        activities, hasMedications, kidsInSchool, schoolLevels, kidsActivities,
        monthlyBudget, mainExpenseCategories, goals,
      } = req.body;

      // Save food preferences
      if ((allergies?.length || dietaryRestrictions?.length || foodDislikes || foodLikes)) {
        await storage.upsertFoodPreferences(a.familyId, a.profileId, {
          likes: foodLikes ? foodLikes.split(",").map((s: string) => s.trim()).filter(Boolean) : [],
          dislikes: foodDislikes ? foodDislikes.split(",").map((s: string) => s.trim()).filter(Boolean) : [],
          allergies: allergies || [],
          dietaryRestrictions: dietaryRestrictions || [],
        });
      }

      // Save structured onboarding profile to ai_cache for later use
      const onboardingProfile = {
        wakeTime, sleepTime, dinnerTime, occupation, whoShops, shoppingFrequency,
        hasPartner, kidsCount: kidsCount || 0, kidsAges: kidsAges || [],
        hasPets, petTypes: petTypes || [],
        homeType, vehicleCount: vehicleCount || 0,
        recurringDeadlines: recurringDeadlines || [],
        activeSubscriptions: activeSubscriptions || [],
        foodDislikes, foodLikes,
        whoCoooks, activities: activities || [],
        hasMedications, kidsInSchool,
        schoolLevels: schoolLevels || [], kidsActivities: kidsActivities || [],
        monthlyBudget, mainExpenseCategories: mainExpenseCategories || [],
        goals: goals || [],
        completedAt: new Date().toISOString(),
      };
      // Fix #37: Upsert instead of accumulating duplicates
      const cacheFeature = `onboarding_profile_${a.profileId}`;
      const [existingCache] = await db.select().from(aiCache).where(and(eq(aiCache.familyId, a.familyId), eq(aiCache.feature, cacheFeature)));
      if (existingCache) {
        await db.update(aiCache).set({ resultJson: JSON.stringify(onboardingProfile), generatedAt: new Date() }).where(eq(aiCache.id, existingCache.id));
      } else {
        await db.insert(aiCache).values({ familyId: a.familyId, feature: cacheFeature, resultJson: JSON.stringify(onboardingProfile) });
      }

      // Fetch profile name
      const profileForPrompt = await storage.getProfileById(a.profileId);
      const profileName = profileForPrompt?.name || "questa persona";

      // Generate rich personalized AI insight
      const kidsDesc = (kidsCount || 0) > 0
        ? `${kidsCount} ${(kidsCount || 0) === 1 ? "figlio" : "figli"}${kidsAges?.length ? ` (${kidsAges.join(", ")})` : ""}${kidsInSchool ? ` a scuola (${(schoolLevels || []).join(", ")})` : ""}${kidsActivities?.length ? `, attività: ${kidsActivities.join(", ")}` : ""}`
        : "nessun figlio";

      const prompt = `
Sei l'assistente di fiducia di una famiglia italiana. ${profileName} ha appena completato la configurazione.
Scrivi un messaggio di benvenuto personalizzato in italiano, massimo 4 frasi, tono caldo e familiare.
Menziona 2-3 aspetti specifici della loro vita. NON usare elenchi puntati. Usa un italiano naturale.

Profilo di ${profileName}:
- Orari: sveglia ${wakeTime || "07:00"}, cena ${dinnerTime || "20:00"}, letto ${sleepTime || "23:00"}
- Occupazione: ${occupation || "non specificata"}
- Famiglia: ${hasPartner ? "con partner" : "senza partner"}, ${kidsDesc}
- Animali: ${hasPets ? (petTypes || []).join(", ") || "sì" : "no"}
- Casa: ${homeType || "non specificato"}, ${vehicleCount || 0} veicolo/i
- Scadenze da seguire: ${(recurringDeadlines || []).join(", ") || "nessuna indicata"}
- Abbonamenti: ${(activeSubscriptions || []).join(", ") || "nessuno"}
- Spesa: ${whoShops || "?"}, ${shoppingFrequency || "?"}, cucina: ${whoCoooks || "?"}
- Allergie: ${(allergies || []).join(", ") || "nessuna"}
- Dieta: ${(dietaryRestrictions || []).join(", ") || "nessuna preferenza"}
- Farmaci regolari: ${hasMedications ? "sì" : "no"}
- Sport/hobby: ${(activities || []).join(", ") || "nessuno indicato"}
- Budget mensile: ${monthlyBudget || "non specificato"}
- Principali spese: ${(mainExpenseCategories || []).join(", ") || "non specificate"}
- Vuole migliorare: ${(goals || []).join(", ") || "non specificato"}
      `.trim();

      const insight = await callClaude(prompt, 300);

      if (insight) {
        await saveInsight(a.familyId, "onboarding_welcome", insight, "info");
      }

      // Mark onboarding as completed
      await db.update(profiles)
        .set({ onboardingCompleted: true } as any)
        .where(eq(profiles.id, a.profileId));

      const updatedProfile = await storage.getProfileById(a.profileId);
      res.json({ profile: updatedProfile ? safe(updatedProfile) : null, insight });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── FAMILY ────────────────────────────────────────────────────────────────
  app.get("/api/family", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const family = await storage.getFamilyById(a.familyId);
      if (!family) return res.status(404).json({ message: "Family not found" });
      res.json(family);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.get("/api/family/members", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const members = await storage.getFamilyMembers(a.familyId);
      res.json(members.map(safe));
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.patch("/api/profile", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { name, colorHex, uiMode } = req.body;
      const updated = await storage.updateProfile(a.profileId, { name, colorHex, uiMode });
      res.json(safe(updated));
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.post("/api/location/pause", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      await storage.setLocationPaused(a.profileId, true);
      res.json({ ok: true, paused: true });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.post("/api/location/resume", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      await storage.setLocationPaused(a.profileId, false);
      res.json({ ok: true, paused: false });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── LOCATIONS ─────────────────────────────────────────────────────────────
  app.post("/api/locations", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { lat, lng, accuracy, speed, isMoving, batteryPct, wifiSsid } = req.body;
      if (lat === undefined || lng === undefined) return res.status(400).json({ message: "Missing coordinates" });
      // Check if paused
      const profile = await storage.getProfileById(a.profileId);
      if (profile?.locationPaused) return res.json({ ok: true, paused: true });
      const loc = await storage.upsertLocation({ userId: a.profileId, familyId: a.familyId, lat, lng, accuracy: accuracy ?? null, speed: speed ?? null, isMoving: isMoving ?? false, batteryPct: batteryPct ?? null, wifiSsid: wifiSsid ?? null, timestamp: new Date() });
      res.json(loc);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.get("/api/family/locations", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const members = await storage.getFamilyMembers(a.familyId);
      const locs = await storage.getLatestLocations(a.familyId);
      const result = members.map(m => ({
        profile: safe(m),
        location: m.locationPaused ? null : (locs.find(l => l.userId === m.id) || null),
        locationPaused: m.locationPaused,
      }));
      res.json(result);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.post("/api/sos", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { lat, lng } = req.body;
      if (lat === undefined || lng === undefined) return res.status(400).json({ message: "Missing coordinates" });
      await storage.upsertLocation({ userId: a.profileId, familyId: a.familyId, lat, lng, accuracy: null, speed: null, isMoving: false, batteryPct: null, wifiSsid: null, timestamp: new Date() });
      const profile = await storage.getProfileById(a.profileId);
      const sosMsg = await storage.createMessage({ familyId: a.familyId, senderId: a.profileId, body: `🆘 SOS! ${profile?.name} ha bisogno di aiuto! Posizione condivisa.`, readBy: [] });
      broadcastToFamily(a.familyId, { type: "sos", message: sosMsg, lat, lng });
      res.json({ ok: true });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── GEOFENCES ─────────────────────────────────────────────────────────────

  // Fix #18: Location history (trajectory for a member, last 24h)
  app.get("/api/locations/history/:userId", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const hours = parseInt(req.query.hours as string) || 24;
      const history = await storage.getLocationHistory(req.params.userId, a.familyId, Math.min(hours, 168)); // max 7 days
      res.json(history);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.get("/api/geofences", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { res.json(await storage.getGeofencesByFamily(a.familyId)); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.post("/api/geofences", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { name, centerLat, centerLng, radiusM, notifyOn, debounceMin } = req.body;
      if (!name || centerLat === undefined || centerLng === undefined) return res.status(400).json({ message: "Missing fields" });
      const g = await storage.createGeofence({ familyId: a.familyId, name, centerLat, centerLng, radiusM: radiusM || 200, notifyOn: notifyOn || "both", debounceMin: debounceMin || 3 });
      res.json(g);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.delete("/api/geofences/:id", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { await storage.deleteGeofence(req.params.id, a.familyId); res.json({ ok: true }); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── EVENTS ────────────────────────────────────────────────────────────────
  app.get("/api/events", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { res.json(await storage.getEventsByFamily(a.familyId)); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.post("/api/events", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { title, description, startAt, endAt, color, reminderMin, assignedTo, category } = req.body;
      if (!title || !startAt) return res.status(400).json({ message: "Missing required fields" });
      const e = await storage.createEvent({ familyId: a.familyId, title, description: description || null, startAt: new Date(startAt), endAt: endAt ? new Date(endAt) : null, color: color || "#3B82F6", reminderMin: reminderMin ?? 30, assignedTo: Array.isArray(assignedTo) ? assignedTo : [], category: category || "other", createdBy: a.profileId });
      res.json(e);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.delete("/api/events/:id", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { await storage.deleteEvent(req.params.id, a.familyId); res.json({ ok: true }); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.patch("/api/events/:id/pickup", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const e = await storage.confirmPickup(req.params.id, a.familyId, a.profileId);
      res.json(e);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── MESSAGES ──────────────────────────────────────────────────────────────
  app.get("/api/messages", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { res.json(await storage.getMessagesByFamily(a.familyId)); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.post("/api/messages", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { body } = req.body;
      if (!body?.trim()) return res.status(400).json({ message: "Empty message" });
      const cleanBody = sanitize(body);
      if (!cleanBody) return res.status(400).json({ message: "Empty message" });
      const m = await storage.createMessage({ familyId: a.familyId, senderId: a.profileId, body: cleanBody, readBy: [a.profileId] });
      // Fix #23: Broadcast to family via WebSocket
      broadcastToFamily(a.familyId, { type: "new_message", message: m }, a.profileId);
      res.json(m);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.post("/api/messages/:id/read", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { await storage.markMessageRead(req.params.id, a.profileId); res.json({ ok: true }); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── SHOPPING ──────────────────────────────────────────────────────────────
  app.get("/api/shopping", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { res.json(await storage.getShoppingItems(a.familyId)); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.post("/api/shopping", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { name, qty, unit, category } = req.body;
      if (!name) return res.status(400).json({ message: "Name required" });
      res.json(await storage.createShoppingItem({ familyId: a.familyId, name, qty: qty || 1, unit: unit || null, category: category || "Other", checked: false, addedBy: a.profileId, checkedBy: null, sortOrder: 0 }));
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.patch("/api/shopping/:id", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { checked } = req.body;
      await storage.updateShoppingItem(req.params.id, a.familyId, { checked, ...(checked ? { checkedBy: a.profileId } : {}) });
      res.json({ ok: true });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.delete("/api/shopping/checked/all", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { await storage.clearCheckedItems(a.familyId); res.json({ ok: true }); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.delete("/api/shopping/:id", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { await storage.deleteShoppingItem(req.params.id, a.familyId); res.json({ ok: true }); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── MEDICATIONS ───────────────────────────────────────────────────────────
  app.get("/api/medications", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { res.json(await storage.getMedicationsByFamily(a.familyId)); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.post("/api/medications", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { profileId, name, dosage, scheduleTimes, notes } = req.body;
      if (!profileId || !name) return res.status(400).json({ message: "Missing fields" });
      res.json(await storage.createMedication({ familyId: a.familyId, profileId, name, dosage: dosage || null, scheduleTimes: Array.isArray(scheduleTimes) ? scheduleTimes : [], lastTakenAt: null, active: true, notes: notes || null }));
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.post("/api/medications/:id/taken", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      await storage.updateMedication(req.params.id, a.familyId, { lastTakenAt: new Date() });
      res.json({ ok: true });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.delete("/api/medications/:id", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { await storage.deleteMedication(req.params.id, a.familyId); res.json({ ok: true }); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── HOME DEADLINES ────────────────────────────────────────────────────────
  app.get("/api/deadlines", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { res.json(await storage.getHomeDeadlines(a.familyId)); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.post("/api/deadlines", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { title, dueDate, category, reminderDaysBefore, notes } = req.body;
      if (!title || !dueDate) return res.status(400).json({ message: "Missing fields" });
      res.json(await storage.createHomeDeadline({ familyId: a.familyId, title, dueDate: new Date(dueDate), category: category || "other", reminderDaysBefore: reminderDaysBefore || 7, notes: notes || null, completed: false }));
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.patch("/api/deadlines/:id", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { title, dueDate, category, reminderDaysBefore, notes, completed } = req.body;
      const updates: Record<string, any> = {};
      if (title !== undefined) updates.title = title;
      if (dueDate !== undefined) updates.dueDate = new Date(dueDate);
      if (category !== undefined) updates.category = category;
      if (reminderDaysBefore !== undefined) updates.reminderDaysBefore = reminderDaysBefore;
      if (notes !== undefined) updates.notes = notes;
      if (completed !== undefined) updates.completed = completed;
      await storage.updateHomeDeadline(req.params.id, a.familyId, updates);
      res.json({ ok: true });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.delete("/api/deadlines/:id", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { await storage.deleteHomeDeadline(req.params.id, a.familyId); res.json({ ok: true }); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── TASKS & REWARDS ───────────────────────────────────────────────────────
  app.get("/api/tasks", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { res.json(await storage.getTasksByFamily(a.familyId)); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.post("/api/tasks", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { assignedTo, title, description, points } = req.body;
      if (!assignedTo || !title) return res.status(400).json({ message: "Missing fields" });
      res.json(await storage.createTask({ familyId: a.familyId, assignedTo, title, description: description || null, points: points || 10, completedAt: null, verifiedBy: null, createdBy: a.profileId }));
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.post("/api/tasks/:id/complete", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { await storage.completeTask(req.params.id, a.familyId); res.json({ ok: true }); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.post("/api/tasks/:id/verify", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { await storage.verifyTask(req.params.id, a.profileId, a.familyId); res.json({ ok: true }); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.delete("/api/tasks/:id", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { await storage.deleteTask(req.params.id, a.familyId); res.json({ ok: true }); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.get("/api/rewards", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { res.json(await storage.getRewards(a.familyId)); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── CHECK-INS ─────────────────────────────────────────────────────────────
  app.get("/api/checkins", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { res.json(await storage.getCheckinsByFamily(a.familyId)); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // Fix #6: Removed duplicate broken POST /api/checkins (the correct one with gamification is below)

  // ─── BUDGET CATEGORIES ─────────────────────────────────────────────────────
  app.get("/api/budget/categories", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { res.json(await storage.getBudgetCategories(a.familyId)); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.post("/api/budget/categories", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { name, budgetAmount, color, icon } = req.body;
      if (!name) return res.status(400).json({ message: "Name required" });
      const cat = await storage.createBudgetCategory({
        familyId: a.familyId, name,
        budgetAmount: budgetAmount ?? 0,
        color: color || "#3B82F6",
        icon: icon || "wallet",
      });
      res.json(cat);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.patch("/api/budget/categories/:id", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      await storage.updateBudgetCategory(req.params.id, a.familyId, req.body);
      res.json({ ok: true });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.delete("/api/budget/categories/:id", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { await storage.deleteBudgetCategory(req.params.id, a.familyId); res.json({ ok: true }); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── EXPENSES ──────────────────────────────────────────────────────────────
  app.get("/api/budget/expenses", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      // Fix #17: Support pagination via query params
      const limit = Math.min(parseInt(req.query.limit as string) || 100, 500);
      const offset = parseInt(req.query.offset as string) || 0;
      const from = req.query.from ? new Date(req.query.from as string) : undefined;
      const to = req.query.to ? new Date(req.query.to as string) : undefined;
      const all = await storage.getExpensesByFamily(a.familyId, from, to);
      res.json(all.slice(offset, offset + limit));
    }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.post("/api/budget/expenses", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { title, amount, categoryId, date, notes } = req.body;
      if (!title || amount === undefined) return res.status(400).json({ message: "Title and amount required" });
      const expense = await storage.createExpense({
        familyId: a.familyId, title, amount: parseFloat(amount),
        categoryId: categoryId || null,
        date: date ? new Date(date) : new Date(),
        addedBy: a.profileId,
        notes: notes || null,
      });
      res.json(expense);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.delete("/api/budget/expenses/:id", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { await storage.deleteExpense(req.params.id, a.familyId); res.json({ ok: true }); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── PETS ───────────────────────────────────────────────────────────────────
  app.get("/api/pets", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { res.json(await storage.getPetsByFamily(a.familyId)); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });
  app.post("/api/pets", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { name, species, breed, birthDate, color, vetName, vetPhone, notes } = req.body;
      if (!name) return res.status(400).json({ message: "Name required" });
      const pet = await storage.createPet({ familyId: a.familyId, name, species: species || "dog", breed: breed || null, birthDate: birthDate ? new Date(birthDate) : null, color: color || "#F59E0B", vetName: vetName || null, vetPhone: vetPhone || null, notes: notes || null });
      res.json(pet);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });
  app.patch("/api/pets/:id", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { name, species, breed, birthDate, color, vetName, vetPhone, notes } = req.body;
      const updates: Record<string, any> = {};
      if (name !== undefined) updates.name = name;
      if (species !== undefined) updates.species = species;
      if (breed !== undefined) updates.breed = breed;
      if (birthDate !== undefined) updates.birthDate = birthDate ? new Date(birthDate) : null;
      if (color !== undefined) updates.color = color;
      if (vetName !== undefined) updates.vetName = vetName;
      if (vetPhone !== undefined) updates.vetPhone = vetPhone;
      if (notes !== undefined) updates.notes = notes;
      await storage.updatePet(req.params.id, a.familyId, updates); res.json({ ok: true }); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });
  app.delete("/api/pets/:id", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { await storage.deletePet(req.params.id, a.familyId); res.json({ ok: true }); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.get("/api/pets/events", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { res.json(await storage.getPetEvents(a.familyId, req.query.petId as string | undefined)); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });
  app.post("/api/pets/events", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { petId, type, title, date, nextDueDate, notes } = req.body;
      if (!petId || !title || !date) return res.status(400).json({ message: "petId, title, date required" });
      const ev = await storage.createPetEvent({ familyId: a.familyId, petId, type: type || "checkup", title, date: new Date(date), nextDueDate: nextDueDate ? new Date(nextDueDate) : null, notes: notes || null });
      res.json(ev);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });
  app.delete("/api/pets/events/:id", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { await storage.deletePetEvent(req.params.id, a.familyId); res.json({ ok: true }); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── VEHICLES ───────────────────────────────────────────────────────────────
  app.get("/api/vehicles", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { res.json(await storage.getVehiclesByFamily(a.familyId)); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });
  app.post("/api/vehicles", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { name, brand, model, plate, year, color, currentKm, insuranceExpiry, revisionExpiry, bolloExpiry } = req.body;
      if (!name) return res.status(400).json({ message: "Name required" });
      const v = await storage.createVehicle({ familyId: a.familyId, name, brand: brand || null, model: model || null, plate: plate || null, year: year ? parseInt(year) : null, color: color || "#3B82F6", currentKm: currentKm ? parseInt(currentKm) : null, insuranceExpiry: insuranceExpiry ? new Date(insuranceExpiry) : null, revisionExpiry: revisionExpiry ? new Date(revisionExpiry) : null, bolloExpiry: bolloExpiry ? new Date(bolloExpiry) : null, currentUserId: null });
      res.json(v);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });
  app.patch("/api/vehicles/:id", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const data = { ...req.body };
      if (data.insuranceExpiry) data.insuranceExpiry = new Date(data.insuranceExpiry);
      if (data.revisionExpiry) data.revisionExpiry = new Date(data.revisionExpiry);
      if (data.bolloExpiry) data.bolloExpiry = new Date(data.bolloExpiry);
      await storage.updateVehicle(req.params.id, a.familyId, data);
      res.json({ ok: true });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });
  app.delete("/api/vehicles/:id", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { await storage.deleteVehicle(req.params.id, a.familyId); res.json({ ok: true }); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.get("/api/vehicles/logs", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { res.json(await storage.getVehicleLogs(a.familyId, req.query.vehicleId as string | undefined)); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });
  app.post("/api/vehicles/logs", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { vehicleId, type, title, date, amount, km, notes } = req.body;
      if (!vehicleId || !title) return res.status(400).json({ message: "vehicleId and title required" });
      const log = await storage.createVehicleLog({ familyId: a.familyId, vehicleId, type: type || "fuel", title, date: date ? new Date(date) : new Date(), amount: amount ? parseFloat(amount) : null, km: km ? parseInt(km) : null, notes: notes || null });
      res.json(log);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });
  app.delete("/api/vehicles/logs/:id", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { await storage.deleteVehicleLog(req.params.id, a.familyId); res.json({ ok: true }); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── SUBSCRIPTIONS ──────────────────────────────────────────────────────────
  app.get("/api/subscriptions", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { res.json(await storage.getSubscriptionsByFamily(a.familyId)); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });
  app.post("/api/subscriptions", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { name, amount, billingCycle, renewalDate, color, icon, active } = req.body;
      if (!name || amount === undefined) return res.status(400).json({ message: "name and amount required" });
      const s = await storage.createSubscription({ familyId: a.familyId, name, amount: parseFloat(amount), billingCycle: billingCycle || "monthly", renewalDate: renewalDate ? new Date(renewalDate) : null, color: color || "#8B5CF6", icon: icon || "tv", active: active !== false });
      res.json(s);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });
  app.patch("/api/subscriptions/:id", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { name, amount, billingCycle, renewalDate, color, icon, active } = req.body;
      const updates: Record<string, any> = {};
      if (name !== undefined) updates.name = name;
      if (amount !== undefined) updates.amount = parseFloat(amount);
      if (billingCycle !== undefined) updates.billingCycle = billingCycle;
      if (renewalDate !== undefined) updates.renewalDate = renewalDate ? new Date(renewalDate) : null;
      if (color !== undefined) updates.color = color;
      if (icon !== undefined) updates.icon = icon;
      if (active !== undefined) updates.active = active;
      await storage.updateSubscription(req.params.id, a.familyId, updates); res.json({ ok: true }); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });
  app.delete("/api/subscriptions/:id", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { await storage.deleteSubscription(req.params.id, a.familyId); res.json({ ok: true }); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── HOME CONTACTS ──────────────────────────────────────────────────────────
  app.get("/api/home-contacts", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { res.json(await storage.getHomeContactsByFamily(a.familyId)); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });
  app.post("/api/home-contacts", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { name, category, phone, email, notes } = req.body;
      if (!name) return res.status(400).json({ message: "Name required" });
      const c = await storage.createHomeContact({ familyId: a.familyId, name, category: category || "other", phone: phone || null, email: email || null, notes: notes || null });
      res.json(c);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });
  app.patch("/api/home-contacts/:id", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { name, category, phone, email, notes } = req.body;
      const updates: Record<string, any> = {};
      if (name !== undefined) updates.name = name;
      if (category !== undefined) updates.category = category;
      if (phone !== undefined) updates.phone = phone;
      if (email !== undefined) updates.email = email;
      if (notes !== undefined) updates.notes = notes;
      await storage.updateHomeContact(req.params.id, a.familyId, updates); res.json({ ok: true }); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });
  app.delete("/api/home-contacts/:id", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { await storage.deleteHomeContact(req.params.id, a.familyId); res.json({ ok: true }); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── ANNIVERSARIES ──────────────────────────────────────────────────────────
  app.get("/api/anniversaries", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { res.json(await storage.getAnniversariesByFamily(a.familyId)); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });
  app.post("/api/anniversaries", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { title, date, type, profileId, reminderDaysBefore } = req.body;
      if (!title || !date) return res.status(400).json({ message: "title and date required" });
      const ann = await storage.createAnniversary({ familyId: a.familyId, title, date: new Date(date), type: type || "birthday", profileId: profileId || null, reminderDaysBefore: reminderDaysBefore ? parseInt(reminderDaysBefore) : 3 });
      res.json(ann);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });
  app.patch("/api/anniversaries/:id", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { title, date, type, profileId, reminderDaysBefore } = req.body;
      const updates: Record<string, any> = {};
      if (title !== undefined) updates.title = title;
      if (date !== undefined) updates.date = new Date(date);
      if (type !== undefined) updates.type = type;
      if (profileId !== undefined) updates.profileId = profileId;
      if (reminderDaysBefore !== undefined) updates.reminderDaysBefore = reminderDaysBefore;
      await storage.updateAnniversary(req.params.id, a.familyId, updates); res.json({ ok: true }); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });
  app.delete("/api/anniversaries/:id", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { await storage.deleteAnniversary(req.params.id, a.familyId); res.json({ ok: true }); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── DINNER ROTATION ────────────────────────────────────────────────────────
  app.get("/api/dinner-rotation", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { res.json(await storage.getDinnerRotationByFamily(a.familyId)); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });
  app.put("/api/dinner-rotation", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { weekday, profileId, meal } = req.body;
      if (weekday === undefined) return res.status(400).json({ message: "weekday required" });
      await storage.upsertDinnerRotation(a.familyId, parseInt(weekday), profileId || null, meal || null);
      res.json({ ok: true });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── BANKING (Open Banking / TrueLayer) ──────────────────────────────────────
  // Helper: get a valid access token for a connection, refreshing if needed
  async function getValidToken(conn: any, familyId: string): Promise<string> {
    if (!conn.accessToken) throw new Error("No access token stored");
    // Fix #4: Decrypt tokens from DB
    const accessToken = decryptField(conn.accessToken);
    const refreshToken = conn.refreshToken ? decryptField(conn.refreshToken) : null;
    const now = new Date();
    const expiry = conn.tokenExpiresAt ? new Date(conn.tokenExpiresAt) : null;
    if (!expiry || expiry.getTime() - now.getTime() < 5 * 60 * 1000) {
      if (!refreshToken) throw new Error("No refresh token available");
      const tokens = await tl.refreshAccessToken(refreshToken);
      await storage.updateBankConnection(conn.id, familyId, {
        accessToken: encryptField(tokens.accessToken),
        refreshToken: encryptField(tokens.refreshToken),
        tokenExpiresAt: tokens.expiresAt,
      });
      return tokens.accessToken;
    }
    return accessToken; // return decrypted token
  }

  app.get("/api/banking/status", async (_req, res) => {
    // If a custom redirect URI is configured, the OAuth redirect goes back to
    // the app automatically. Otherwise we fall back to TrueLayer's own redirect
    // page and the user must paste the return URL manually.
    const customUri = process.env.TRUELAYER_REDIRECT_URI;
    res.json({
      configured: tl.isConfigured(),
      environment: process.env.TRUELAYER_ENVIRONMENT || "production",
      redirectUri: customUri || null,
      needsManualPaste: !customUri,
    });
  });

  // Redirect URI: use env var (production domain) or TrueLayer's pre-approved sandbox page
  const TL_REDIRECT_URI = process.env.TRUELAYER_REDIRECT_URI || "https://console.truelayer.com/redirect-page";

  // Start connect flow: create pending connection, return TrueLayer auth URL
  app.post("/api/banking/connect", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    if (!tl.isConfigured()) return res.status(503).json({ message: "TrueLayer non configurato" });
    try {
      const state = randomBytes(12).toString("hex");
      const authUrl = tl.buildAuthUrl(TL_REDIRECT_URI, state);
      const conn = await storage.createBankConnection({
        familyId: a.familyId,
        profileId: a.profileId,
        requisitionId: state,
        institutionId: "unknown",
        institutionName: "In collegamento…",
        institutionLogo: null,
        status: "pending",
        accountIds: [],
        accessToken: null,
        refreshToken: null,
        tokenExpiresAt: null,
        authUrl,
        lastSyncAt: null,
      });
      res.json({ connectionId: conn.id, authUrl, state });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // OAuth callback: exchange code for tokens, fetch accounts
  app.post("/api/banking/callback", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    if (!tl.isConfigured()) return res.status(503).json({ message: "TrueLayer non configurato" });
    try {
      const { code, state } = req.body;
      if (!code || !state) return res.status(400).json({ message: "code e state obbligatori" });
      // Find matching pending connection by state (stored as requisitionId)
      const conn = await storage.getBankConnectionByRequisition(state);
      if (!conn || conn.familyId !== a.familyId) return res.status(404).json({ message: "Connessione non trovata" });
      // Exchange code for tokens — must use same redirect_uri as auth URL
      const tokens = await tl.exchangeCode(code, TL_REDIRECT_URI);
      // Fetch accounts to populate institution info and account IDs
      const accounts = await tl.getAccounts(tokens.accessToken);
      const accountIds = accounts.map(ac => ac.account_id);
      const provider = accounts[0]?.provider;
      const institutionName = provider?.display_name || "Banca collegata";
      const institutionLogo = provider?.logo_uri || null;
      const institutionId = provider?.provider_id || "unknown";
      await storage.updateBankConnection(conn.id, a.familyId, {
        status: "linked",
        accessToken: encryptField(tokens.accessToken),
        refreshToken: encryptField(tokens.refreshToken),
        tokenExpiresAt: tokens.expiresAt,
        accountIds,
        institutionId,
        institutionName,
        institutionLogo,
        lastSyncAt: new Date(),
      });
      res.json({ ok: true, institutionName, accountCount: accountIds.length });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.get("/api/banking/connections", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const conns = await storage.getBankConnectionsByFamily(a.familyId);
      // Strip tokens from response for security
      res.json(conns.map(({ accessToken, refreshToken, ...safe }) => safe));
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.delete("/api/banking/connections/:id", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const conns = await storage.getBankConnectionsByFamily(a.familyId);
      const conn = conns.find(c => c.id === req.params.id);
      if (conn) {
        if (conn.accessToken) { try { await tl.deleteConnection(decryptField(conn.accessToken)); } catch {} }
        await storage.deleteBankConnection(conn.id, a.familyId);
      }
      res.json({ ok: true });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.get("/api/banking/balances", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    if (!tl.isConfigured()) return res.status(503).json({ message: "TrueLayer non configurato" });
    try {
      const allConns = await storage.getBankConnectionsByFamily(a.familyId);
      const connections = allConns.filter(c => c.status === "linked");
      const results: any[] = [];
      for (const conn of connections) {
        try {
          const token = await getValidToken(conn, a.familyId);
          const accounts = await tl.getAccounts(token);
          for (const acc of accounts) {
            const balance = await tl.getAccountBalance(acc.account_id, token);
            results.push({
              accountId: acc.account_id,
              connectionId: conn.id,
              institutionName: acc.provider?.display_name || conn.institutionName,
              institutionLogo: acc.provider?.logo_uri || conn.institutionLogo,
              iban: acc.account_number?.iban ?? null,
              name: acc.display_name,
              amount: balance?.available ?? balance?.current ?? null,
              currency: acc.currency || "EUR",
            });
          }
        } catch {}
      }
      res.json(results);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.get("/api/banking/transactions", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    if (!tl.isConfigured()) return res.status(503).json({ message: "TrueLayer non configurato" });
    try {
      const allConns = await storage.getBankConnectionsByFamily(a.familyId);
      const connections = allConns.filter(c => c.status === "linked");
      const dateFrom = req.query.dateFrom as string | undefined;
      const dateTo = req.query.dateTo as string | undefined;
      const allTx: any[] = [];
      for (const conn of connections) {
        try {
          const token = await getValidToken(conn, a.familyId);
          const accounts = await tl.getAccounts(token);
          for (const acc of accounts) {
            const txs = await tl.getAccountTransactions(acc.account_id, token, dateFrom, dateTo);
            const mapped = txs.map(t => ({
              id: t.transaction_id || `${acc.account_id}-${t.timestamp}-${t.amount}`,
              accountId: acc.account_id,
              connectionId: conn.id,
              institutionName: acc.provider?.display_name || conn.institutionName,
              institutionLogo: acc.provider?.logo_uri || conn.institutionLogo,
              amount: t.amount,
              currency: t.currency,
              description: t.description || t.merchant_name || "Movimento",
              counterparty: t.merchant_name ?? null,
              date: t.timestamp.slice(0, 10),
              category: t.transaction_category,
              type: t.transaction_type,
            }));
            allTx.push(...mapped);
          }
        } catch {}
      }
      allTx.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      res.json(allTx);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── AI ROUTES ────────────────────────────────────────────────────────────────

  // GET /api/ai/status — check if AI is available
  app.get("/api/ai/status", async (req, res) => {
    try {
      const payload = await auth(req, res);
      if (!payload) return;
      res.json({ available: !!process.env.CLAUDE_API_KEY });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // GET /api/ai/summary — riepilogo serale (cached 12h)
  app.get("/api/ai/summary", async (req, res) => {
    try {
      const payload = await auth(req, res);
      if (!payload) return;
      const cached = await getCached(payload.familyId, "evening_summary", 12);
      if (cached) return res.json(cached);
      const fresh = await generateEveningSummary(payload.familyId);
      res.json(fresh ? { text: fresh } : { text: null });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // GET /api/ai/forecast — previsione spese mensili
  app.get("/api/ai/forecast", async (req, res) => {
    try {
      const payload = await auth(req, res);
      if (!payload) return;
      const result = await generateSpendingForecast(payload.familyId);
      res.json(result ?? { error: "insufficient_data" });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // GET /api/ai/anomalies — anomalie di spesa
  app.get("/api/ai/anomalies", async (req, res) => {
    try {
      const payload = await auth(req, res);
      if (!payload) return;
      const result = await detectAnomalies(payload.familyId);
      res.json(result);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // GET /api/ai/score — health score finanziario
  app.get("/api/ai/score", async (req, res) => {
    try {
      const payload = await auth(req, res);
      if (!payload) return;
      const result = await calculateHealthScore(payload.familyId);
      res.json(result ?? { score: null });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // GET /api/ai/study/:childId — piano studio
  app.get("/api/ai/study/:childId", async (req, res) => {
    try {
      const payload = await auth(req, res);
      if (!payload) return;
      const result = await generateStudyPlan(payload.familyId, req.params.childId);
      res.json(result ?? { study_sessions: [] });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // GET /api/ai/shopping — suggerimenti lista spesa
  app.get("/api/ai/shopping", async (req, res) => {
    try {
      const payload = await auth(req, res);
      if (!payload) return;
      const result = await suggestShoppingItems(payload.familyId);
      res.json(result);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // GET /api/ai/insights — tutti gli insight recenti (ultimi 20)
  app.get("/api/ai/insights", async (req, res) => {
    try {
      const payload = await auth(req, res);
      if (!payload) return;
      const rows = await db
        .select()
        .from(aiInsights)
        .where(eq(aiInsights.familyId, payload.familyId))
        .orderBy(desc(aiInsights.createdAt))
        .limit(20);
      res.json(rows);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // POST /api/ai/insights/:id/read — segna insight come letto
  app.post("/api/ai/insights/:id/read", async (req, res) => {
    try {
      const payload = await auth(req, res);
      if (!payload) return;
      await db
        .update(aiInsights)
        .set({ readAt: new Date() })
        .where(and(eq(aiInsights.id, req.params.id), eq(aiInsights.familyId, payload.familyId)));
      res.json({ ok: true });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── PROFILE SETTINGS ─────────────────────────────────────────────────────

  // GET /api/profile/settings
  app.get("/api/profile/settings", async (req, res) => {
    try {
      const payload = await auth(req, res);
      if (!payload) return;
      let [settings] = await db.select().from(profileSettings).where(eq(profileSettings.profileId, payload.profileId));
      if (!settings) {
        const [created] = await db.insert(profileSettings).values({ profileId: payload.profileId }).returning();
        settings = created;
      }
      res.json(settings);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // PATCH /api/profile/mood
  app.patch("/api/profile/mood", async (req, res) => {
    try {
      const payload = await auth(req, res);
      if (!payload) return;
      const { mood } = req.body;
      const valid = ["happy", "excited", "sleeping", "focused", "neutral", "sad"];
      if (!valid.includes(mood)) return res.status(400).json({ message: "Invalid mood" });
      const [row] = await db.update(profiles).set({ currentMood: mood }).where(eq(profiles.id, payload.profileId)).returning();
      res.json(row);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // GET /api/profile/mood-photos — all mood photos for the current user
  app.get("/api/profile/mood-photos", async (req, res) => {
    try {
      const payload = await auth(req, res); if (!payload) return;
      const rows = await db.select().from(moodPhotos).where(eq(moodPhotos.profileId, payload.profileId));
      res.json(rows);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // POST /api/profile/mood-photos/upload-url — presigned URL for mood photo upload
  app.post("/api/profile/mood-photos/upload-url", async (req, res) => {
    const payload = await auth(req, res); if (!payload) return;
    try {
      const { name, size, contentType } = req.body;
      const uploadURL = await objStore.getObjectEntityUploadURL();
      const objectPath = objStore.normalizeObjectEntityPath(uploadURL);
      res.json({ uploadURL, objectPath, metadata: { name, size, contentType } });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // POST /api/profile/mood-photos — upsert a mood photo (base64 legacy OR objectPath new)
  app.post("/api/profile/mood-photos", async (req, res) => {
    try {
      const payload = await auth(req, res); if (!payload) return;
      const { mood, photoBase64, objectPath } = req.body;
      const valid = ["happy", "excited", "sleeping", "focused", "neutral", "sad"];
      if (!valid.includes(mood) || (!photoBase64 && !objectPath)) return res.status(400).json({ message: "Invalid payload" });
      const updateData: any = { updatedAt: new Date() };
      if (objectPath) { updateData.objectPath = objectPath; updateData.photoBase64 = null; }
      else { updateData.photoBase64 = photoBase64; updateData.objectPath = null; }

      const [existing] = await db.select({ id: moodPhotos.id }).from(moodPhotos)
        .where(and(eq(moodPhotos.profileId, payload.profileId), eq(moodPhotos.mood, mood)));
      let row;
      if (existing) {
        [row] = await db.update(moodPhotos).set(updateData)
          .where(and(eq(moodPhotos.profileId, payload.profileId), eq(moodPhotos.mood, mood))).returning();
      } else {
        [row] = await db.insert(moodPhotos).values({ profileId: payload.profileId, mood, ...updateData }).returning();
      }
      res.json(row);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // GET /api/family/mood-photos — compact map for all family members; returns objectPath or base64
  app.get("/api/family/mood-photos", async (req, res) => {
    try {
      const payload = await auth(req, res); if (!payload) return;
      const members = await storage.getFamilyMembers(payload.familyId);
      const memberIds = members.map(m => m.id);
      // Fix #7: Query only relevant rows instead of full table scan
      const rows = memberIds.length > 0
        ? await db.select().from(moodPhotos).where(inArray(moodPhotos.profileId, memberIds))
        : [];
      // Return { profileId: { mood: { src, isObjectPath } } }
      const map: Record<string, Record<string, { src: string; isObjectPath: boolean }>> = {};
      for (const r of rows) {
        if (!map[r.profileId]) map[r.profileId] = {};
        if (r.objectPath) {
          map[r.profileId][r.mood] = { src: r.objectPath, isObjectPath: true };
        } else if (r.photoBase64) {
          map[r.profileId][r.mood] = { src: r.photoBase64, isObjectPath: false };
        }
      }
      res.json(map);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // DELETE /api/profile/mood-photos/:mood — remove a mood photo
  app.delete("/api/profile/mood-photos/:mood", async (req, res) => {
    try {
      const payload = await auth(req, res); if (!payload) return;
      await db.delete(moodPhotos).where(and(eq(moodPhotos.profileId, payload.profileId), eq(moodPhotos.mood, req.params.mood)));
      res.json({ ok: true });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // POST /api/profile/avatar-upload-url — presigned URL for avatar upload
  app.post("/api/profile/avatar-upload-url", async (req, res) => {
    const payload = await auth(req, res); if (!payload) return;
    try {
      const { name, size, contentType } = req.body;
      const uploadURL = await objStore.getObjectEntityUploadURL();
      const objectPath = objStore.normalizeObjectEntityPath(uploadURL);
      res.json({ uploadURL, objectPath, metadata: { name, size, contentType } });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // GET /api/photos/:id — serve a file from object storage by UUID id (authenticated)
  app.get("/api/photos/:id", async (req, res) => {
    const payload = await auth(req, res); if (!payload) return;
    try {
      const fullPath = `/objects/uploads/${req.params.id}`;
      const file = await objStore.getObjectEntityFile(fullPath);
      await objStore.downloadObject(file, res);
    } catch (e: any) {
      if (e instanceof ObjectNotFoundError) return res.status(404).json({ message: "Non trovato" });
      res.status(500).json({ message: e.message });
    }
  });

  // PATCH /api/profile/settings
  app.patch("/api/profile/settings", async (req, res) => {
    try {
      const payload = await auth(req, res);
      if (!payload) return;
      const allowed = ["schoolModeEnabled", "schoolModeFrom", "schoolModeTo", "schoolModeDays",
        "elderlyTrackingEnabled", "nightAlertEnabled", "nightAlertFrom", "nightAlertTo",
        "safeZonesOnly", "caregiverPhone", "caregiverName", "batteryMode"];
      const updates: Record<string, any> = {};
      for (const k of allowed) { if (req.body[k] !== undefined) updates[k] = req.body[k]; }
      updates.updatedAt = new Date();
      const [existing] = await db.select({ id: profileSettings.id }).from(profileSettings).where(eq(profileSettings.profileId, payload.profileId));
      if (existing) {
        const [row] = await db.update(profileSettings).set(updates).where(eq(profileSettings.profileId, payload.profileId)).returning();
        res.json(row);
      } else {
        const [row] = await db.insert(profileSettings).values({ profileId: payload.profileId, ...updates }).returning();
        res.json(row);
      }
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // GET /api/profile/family-settings — settings di tutti i membri (per monitoraggio anziani/scuola)
  app.get("/api/profile/family-settings", async (req, res) => {
    try {
      const payload = await auth(req, res);
      if (!payload) return;
      const members = await db.select().from(profiles).where(eq(profiles.familyId, payload.familyId));
      // Fix #8: Single query for all settings instead of N+1
      const memberIds = members.map(m => m.id);
      const allSettings = memberIds.length > 0
        ? await db.select().from(profileSettings).where(inArray(profileSettings.profileId, memberIds))
        : [];
      const settingsMap = new Map(allSettings.map(s => [s.profileId, s]));
      const result = members.map(m => ({
        profile: { id: m.id, name: m.name, role: m.role, colorHex: m.colorHex },
        settings: settingsMap.get(m.id) || null,
      }));
      res.json(result);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── CHECK-IN CONSENSUALE ─────────────────────────────────────────────────

  // POST /api/checkins — check-in volontario con punto gamification
  app.post("/api/checkins", async (req, res) => {
    try {
      const payload = await auth(req, res);
      if (!payload) return;
      const { placeName, lat, lng, note } = req.body;
      if (!placeName) return res.status(400).json({ message: "placeName obbligatorio" });
      const [checkin] = await db.insert(checkins).values({ userId: payload.profileId, familyId: payload.familyId, placeName, lat: lat || null, lng: lng || null, note: note || null }).returning();

      // Aggiorna streak e punti
      const today = new Date().toISOString().split("T")[0];
      const [settings] = await db.select().from(profileSettings).where(eq(profileSettings.profileId, payload.profileId));
      const lastDate = settings?.lastCheckInDate;
      const yesterday = new Date(Date.now() - 86400000).toISOString().split("T")[0];
      const newStreak = lastDate === yesterday ? (settings?.checkInStreak || 0) + 1 : lastDate === today ? (settings?.checkInStreak || 0) : 1;
      const newTotal = (settings?.checkInTotal || 0) + 1;
      const pointsEarned = newStreak >= 7 ? 20 : newStreak >= 3 ? 15 : 10;

      if (settings) {
        await db.update(profileSettings).set({ checkInStreak: newStreak, checkInTotal: newTotal, lastCheckInDate: today }).where(eq(profileSettings.profileId, payload.profileId));
      } else {
        await db.insert(profileSettings).values({ profileId: payload.profileId, checkInStreak: newStreak, checkInTotal: newTotal, lastCheckInDate: today });
      }

      // Aggiorna reward points
      const [reward] = await db.select().from(rewards).where(eq(rewards.profileId, payload.profileId));
      if (reward) {
        await db.update(rewards).set({ pointsTotal: reward.pointsTotal + pointsEarned }).where(eq(rewards.profileId, payload.profileId));
      } else {
        await db.insert(rewards).values({ profileId: payload.profileId, familyId: payload.familyId, pointsTotal: pointsEarned, pointsSpent: 0 });
      }

      res.json({ checkin, pointsEarned, streak: newStreak, total: newTotal });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // GET /api/checkins/family — ultimi check-in di tutta la famiglia
  app.get("/api/checkins/family", async (req, res) => {
    try {
      const payload = await auth(req, res);
      if (!payload) return;
      const rows = await db.select({
        id: checkins.id, userId: checkins.userId, familyId: checkins.familyId,
        placeName: checkins.placeName, lat: checkins.lat, lng: checkins.lng,
        note: checkins.note, createdAt: checkins.createdAt,
        memberName: profiles.name, memberColor: profiles.colorHex,
      })
        .from(checkins)
        .innerJoin(profiles, eq(checkins.userId, profiles.id))
        .where(eq(checkins.familyId, payload.familyId))
        .orderBy(desc(checkins.createdAt))
        .limit(30);
      res.json(rows);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // GET /api/checkins/mine — miei check-in con streak
  app.get("/api/checkins/mine", async (req, res) => {
    try {
      const payload = await auth(req, res);
      if (!payload) return;
      const rows = await db.select().from(checkins).where(eq(checkins.userId, payload.profileId)).orderBy(desc(checkins.createdAt)).limit(20);
      const [settings] = await db.select().from(profileSettings).where(eq(profileSettings.profileId, payload.profileId));
      const [reward] = await db.select().from(rewards).where(eq(rewards.profileId, payload.profileId));
      res.json({ checkins: rows, streak: settings?.checkInStreak || 0, total: settings?.checkInTotal || 0, points: reward?.pointsTotal || 0 });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── AI NARRATIVA PER MEMBRO ──────────────────────────────────────────────

  // GET /api/ai/narrative/:memberId
  app.get("/api/ai/narrative/:memberId", async (req, res) => {
    try {
      const payload = await auth(req, res);
      if (!payload) return;
      const narrative = await generateMemberNarrative(payload.familyId, req.params.memberId);
      res.json({ narrative: narrative || "Nessun dato disponibile per generare la narrativa." });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── SCHOOL ───────────────────────────────────────────────────────────────

  // GET /api/school/connections
  app.get("/api/school/connections", async (req, res) => {
    try {
      const payload = await auth(req, res);
      if (!payload) return;
      const rows = await db.select().from(schoolConnections).where(eq(schoolConnections.familyId, payload.familyId)).orderBy(desc(schoolConnections.createdAt));
      const safe = rows.map(r => ({ ...r, password: "***" }));
      res.json(safe);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // POST /api/school/connect — aggiunge e verifica una connessione
  app.post("/api/school/connect", async (req, res) => {
    try {
      const payload = await auth(req, res);
      if (!payload) return;
      const { platform, username, password, schoolCode, studentName } = req.body;
      if (!platform || !username || !password || !studentName) return res.status(400).json({ message: "Campi obbligatori mancanti" });

      let studentId = "";
      let resolvedName = studentName;
      try {
        if (platform === "classeviva") {
          const session = await classevivaLogin(username, password);
          studentId = session.studentId;
          if (session.firstName || session.lastName) resolvedName = `${session.firstName} ${session.lastName}`.trim();
        } else if (platform === "argo") {
          if (!schoolCode) return res.status(400).json({ message: "Codice scuola obbligatorio per Argo" });
          const session = await argoLogin(schoolCode, username, password);
          studentId = session.studentId;
          if (session.firstName || session.lastName) resolvedName = `${session.firstName} ${session.lastName}`.trim();
        } else {
          return res.status(400).json({ message: "Piattaforma non supportata" });
        }
      } catch (e: any) {
        return res.status(401).json({ message: `Credenziali non valide: ${e.message}` });
      }

      const [conn] = await db.insert(schoolConnections).values({
        familyId: payload.familyId,
        userId: payload.profileId,
        platform,
        studentName: resolvedName,
        schoolCode: schoolCode || null,
        username,
        password: encryptField(password), // Fix #2: encrypt at rest
        studentId,
      }).returning();

      res.json({ ...conn, password: "***" });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // DELETE /api/school/connections/:id
  app.delete("/api/school/connections/:id", async (req, res) => {
    try {
      const payload = await auth(req, res);
      if (!payload) return;
      const conn = await db.select().from(schoolConnections).where(and(eq(schoolConnections.id, req.params.id), eq(schoolConnections.familyId, payload.familyId)));
      if (!conn.length) return res.status(404).json({ message: "Connessione non trovata" });
      await db.delete(schoolGrades).where(eq(schoolGrades.connectionId, req.params.id));
      await db.delete(schoolAbsences).where(eq(schoolAbsences.connectionId, req.params.id));
      await db.delete(schoolHomework).where(eq(schoolHomework.connectionId, req.params.id));
      await db.delete(schoolNotices).where(eq(schoolNotices.connectionId, req.params.id));
      await db.delete(schoolConnections).where(eq(schoolConnections.id, req.params.id));
      res.json({ ok: true });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // POST /api/school/sync/:id — sincronizza voti, assenze, compiti, avvisi
  app.post("/api/school/sync/:id", async (req, res) => {
    try {
      const payload = await auth(req, res);
      if (!payload) return;
      const [conn] = await db.select().from(schoolConnections).where(and(eq(schoolConnections.id, req.params.id), eq(schoolConnections.familyId, payload.familyId)));
      if (!conn) return res.status(404).json({ message: "Connessione non trovata" });

      let grades: any[] = [], absences: any[] = [], homework: any[] = [], notices: any[] = [];

      if (conn.platform === "classeviva") {
        let session;
        try { session = await classevivaLogin(conn.username, decryptField(conn.password)); }
        catch (e: any) {
          await db.update(schoolConnections).set({ syncError: e.message }).where(eq(schoolConnections.id, conn.id));
          return res.status(401).json({ message: `Login fallito: ${e.message}` });
        }
        [grades, absences, homework, notices] = await Promise.all([
          classevivaGrades(session),
          classevivaAbsences(session),
          classevivaHomework(session),
          classevivaNotices(session),
        ]);
      } else if (conn.platform === "argo") {
        let session;
        try { session = await argoLogin(conn.schoolCode!, conn.username, decryptField(conn.password)); }
        catch (e: any) {
          await db.update(schoolConnections).set({ syncError: e.message }).where(eq(schoolConnections.id, conn.id));
          return res.status(401).json({ message: `Login fallito: ${e.message}` });
        }
        [grades, absences, homework, notices] = await Promise.all([
          argoGrades(session),
          argoAbsences(session),
          argoHomework(session),
          argoNotices(session),
        ]);
      }

      // Elimina vecchi dati e reinserisce
      await db.delete(schoolGrades).where(eq(schoolGrades.connectionId, conn.id));
      await db.delete(schoolAbsences).where(eq(schoolAbsences.connectionId, conn.id));
      await db.delete(schoolHomework).where(eq(schoolHomework.connectionId, conn.id));
      await db.delete(schoolNotices).where(eq(schoolNotices.connectionId, conn.id));

      if (grades.length) await db.insert(schoolGrades).values(grades.map((g: any) => ({ ...g, connectionId: conn.id, familyId: conn.familyId })));
      if (absences.length) await db.insert(schoolAbsences).values(absences.map((a: any) => ({ ...a, connectionId: conn.id, familyId: conn.familyId })));
      if (homework.length) await db.insert(schoolHomework).values(homework.map((h: any) => ({ ...h, connectionId: conn.id, familyId: conn.familyId })));
      if (notices.length) await db.insert(schoolNotices).values(notices.map((n: any) => ({ ...n, connectionId: conn.id, familyId: conn.familyId })));

      await db.update(schoolConnections).set({ lastSync: new Date(), syncError: null }).where(eq(schoolConnections.id, conn.id));
      res.json({ grades: grades.length, absences: absences.length, homework: homework.length, notices: notices.length });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // GET /api/school/grades/:connectionId
  app.get("/api/school/grades/:connectionId", async (req, res) => {
    try {
      const payload = await auth(req, res);
      if (!payload) return;
      const rows = await db.select().from(schoolGrades).where(and(eq(schoolGrades.connectionId, req.params.connectionId), eq(schoolGrades.familyId, payload.familyId))).orderBy(desc(schoolGrades.date));
      res.json(rows);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // GET /api/school/absences/:connectionId
  app.get("/api/school/absences/:connectionId", async (req, res) => {
    try {
      const payload = await auth(req, res);
      if (!payload) return;
      const rows = await db.select().from(schoolAbsences).where(and(eq(schoolAbsences.connectionId, req.params.connectionId), eq(schoolAbsences.familyId, payload.familyId))).orderBy(desc(schoolAbsences.date));
      res.json(rows);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // GET /api/school/homework/:connectionId
  app.get("/api/school/homework/:connectionId", async (req, res) => {
    try {
      const payload = await auth(req, res);
      if (!payload) return;
      const rows = await db.select().from(schoolHomework).where(and(eq(schoolHomework.connectionId, req.params.connectionId), eq(schoolHomework.familyId, payload.familyId))).orderBy(desc(schoolHomework.givenAt));
      res.json(rows);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // GET /api/school/notices/:connectionId
  app.get("/api/school/notices/:connectionId", async (req, res) => {
    try {
      const payload = await auth(req, res);
      if (!payload) return;
      const rows = await db.select().from(schoolNotices).where(and(eq(schoolNotices.connectionId, req.params.connectionId), eq(schoolNotices.familyId, payload.familyId))).orderBy(desc(schoolNotices.date));
      res.json(rows);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // PATCH /api/school/homework/:id/done — segna compito fatto/non fatto
  app.patch("/api/school/homework/:id/done", async (req, res) => {
    try {
      const payload = await auth(req, res);
      if (!payload) return;
      const { done } = req.body;
      await db.update(schoolHomework).set({ done: !!done }).where(and(eq(schoolHomework.id, req.params.id), eq(schoolHomework.familyId, payload.familyId)));
      res.json({ ok: true });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // POST /api/briefing/chat — AI assistant for Briefing page
  app.post("/api/briefing/chat", async (req, res) => {
    try {
      const a = await auth(req, res);
      if (!a) return;
      const { message } = req.body;
      if (!message?.trim()) return res.status(400).json({ message: "Messaggio vuoto" });

      const [family, members, eventsData, medsData, tasksData, shoppingData] = await Promise.all([
        storage.getFamilyById(a.familyId),
        storage.getFamilyMembers(a.familyId),
        storage.getEventsByFamily(a.familyId),
        storage.getMedicationsByFamily(a.familyId),
        storage.getTasksByFamily(a.familyId),
        storage.getShoppingItems(a.familyId),
      ]);

      const now = new Date();
      const upcoming = eventsData
        .filter(e => new Date(e.startAt) > now)
        .sort((a, b) => new Date(a.startAt).getTime() - new Date(b.startAt).getTime())
        .slice(0, 3);
      const pendingTasks = tasksData.filter(t => !t.completedAt).length;
      const pendingItems = shoppingData.filter(i => !i.checked).length;
      const activeMeds = medsData.filter(m => m.active);

      const context = [
        `Famiglia: ${family?.name || "Sconosciuta"}`,
        `Ora: ${now.toLocaleString("it-IT")}`,
        `Membri: ${members.map(m => `${m.name} (${m.role})`).join(", ")}`,
        upcoming.length > 0
          ? `Prossimi eventi: ${upcoming.map(e => `"${e.title}" il ${new Date(e.startAt).toLocaleString("it-IT")}`).join("; ")}`
          : "Nessun evento in programma",
        activeMeds.length > 0
          ? `Farmaci attivi: ${activeMeds.map(m => `${m.name} (${m.scheduleTimes?.join(", ")})`).join(", ")}`
          : "Nessun farmaco attivo",
        `Compiti in sospeso: ${pendingTasks}`,
        `Articoli da comprare: ${pendingItems}`,
      ].join("\n");

      const prompt = `Sei l'assistente AI di FamilyTracker, un'app italiana di coordinamento familiare. Rispondi sempre in italiano, in modo conciso, caldo e utile. Non elencare mai dati raw — sintetizza e dai consigli pratici. Massimo 3-4 frasi.

Contesto attuale della famiglia:
${context}

L'utente dice: "${message}"

Risposta:`;

      const reply = await callClaude(prompt, 350);
      if (!reply) return res.status(503).json({ message: "AI temporaneamente non disponibile" });
      res.json({ reply });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── KITCHEN AI ────────────────────────────────────────────────────────────
  app.get("/api/kitchen/preferences", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try { res.json(await storage.getFoodPreferences(a.familyId)); }
    catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.put("/api/kitchen/preferences", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { profileId, likes, dislikes, allergies, dietaryRestrictions } = req.body;
      const result = await storage.upsertFoodPreferences(a.familyId, profileId || null, { likes, dislikes, allergies, dietaryRestrictions });
      res.json(result);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.post("/api/kitchen/scan", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { imageBase64, mediaType = "image/jpeg", mode = "recipes" } = req.body;
      if (!imageBase64) return res.status(400).json({ message: "imageBase64 obbligatorio" });

      const prefs = await storage.getFoodPreferences(a.familyId);
      const shopping = await storage.getShoppingItems(a.familyId);
      const boughtItems = shopping.map((s: any) => s.name).join(", ") || "nessuno";

      const allergiesInfo = prefs.flatMap(p => p.allergies || []).filter(Boolean).join(", ") || "nessuna";
      const dislikesInfo = prefs.flatMap(p => p.dislikes || []).filter(Boolean).join(", ") || "nessuno";

      let prompt: string;
      if (mode === "missing") {
        prompt = `Analizza questa foto del frigo/dispensa. 
Prodotti che la famiglia acquista abitualmente: ${boughtItems}.
Allergie/intolleranze: ${allergiesInfo}.

Identifica cosa manca rispetto agli acquisti abituali. Rispondi SOLO con questo JSON (nessun testo prima o dopo):
{"missingItems": [{"name": "...", "category": "...", "priority": "alta|media|bassa", "reason": "..."}], "detectedItems": ["item1", "item2"]}`;
      } else {
        prompt = `Analizza questa foto del frigo/dispensa.
Allergie/intolleranze da evitare: ${allergiesInfo}.
Ingredienti da evitare: ${dislikesInfo}.

Identifica tutti gli ingredienti visibili e proponi 3 ricette creative che si possono preparare con ciò che c'è. Rispondi SOLO con questo JSON (nessun testo prima o dopo):
{"detectedIngredients": ["ing1", "ing2"], "recipes": [{"name": "...", "time": "...", "difficulty": "facile|media|difficile", "ingredients": ["..."], "steps": ["..."], "emoji": "🍝"}]}`;
      }

      const raw = await callClaudeVision(prompt, imageBase64, mediaType, 1500);
      if (!raw) return res.status(503).json({ message: "AI temporaneamente non disponibile" });
      const result = parseJSON(raw);
      if (!result) return res.status(500).json({ message: "Risposta AI non valida", raw });
      res.json(result);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.post("/api/kitchen/menu", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const prefs = await storage.getFoodPreferences(a.familyId);
      const members = await storage.getFamilyMembers(a.familyId);
      const shopping = await storage.getShoppingItems(a.familyId);
      const availableItems = shopping.filter((s: any) => !s.checked).map((s: any) => s.name).join(", ") || "nessuno";

      const allergies = prefs.flatMap(p => p.allergies || []).filter(Boolean);
      const dislikes = prefs.flatMap(p => p.dislikes || []).filter(Boolean);
      const likes = prefs.flatMap(p => p.likes || []).filter(Boolean);
      const dietary = prefs.flatMap(p => p.dietaryRestrictions || []).filter(Boolean);
      const names = members.map((m: any) => m.name.split(" ")[0]).join(", ");

      const prompt = `Sei uno chef italiano che crea menu settimanali per famiglie.
Famiglia: ${names} (${members.length} persone).
Piatti preferiti: ${likes.join(", ") || "nessuna preferenza"}.
Allergie/intolleranze: ${allergies.join(", ") || "nessuna"}.
Da evitare: ${dislikes.join(", ") || "nessuno"}.
Restrizioni dietetiche: ${dietary.join(", ") || "nessuna"}.
Ingredienti già disponibili: ${availableItems}.

Crea un menu per 7 giorni (pranzo e cena per ogni giorno) bilanciato e vario, usando ingredienti stagionali italiani. Rispondi SOLO con questo JSON:
{"week": [{"day": "Lunedì", "lunch": {"name": "...", "time": "...", "emoji": "🍝"}, "dinner": {"name": "...", "time": "...", "emoji": "🍖"}}]}`;

      const raw = await callClaude(prompt, 2000);
      if (!raw) return res.status(503).json({ message: "AI temporaneamente non disponibile" });
      const result = parseJSON(raw);
      if (!result) return res.status(500).json({ message: "Risposta AI non valida" });
      res.json(result);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── Documents ───────────────────────────────────────────────────────────────
  const objStore = new ObjectStorageService();

  // Presigned URL for direct-to-cloud document upload
  app.post("/api/documents/upload-url", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { name, size, contentType } = req.body;
      if (!name) return res.status(400).json({ message: "name obbligatorio" });
      const uploadURL = await objStore.getObjectEntityUploadURL();
      const objectPath = objStore.normalizeObjectEntityPath(uploadURL);
      res.json({ uploadURL, objectPath, metadata: { name, size, contentType } });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.get("/api/documents", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    const section = req.query.section as string | undefined;
    try {
      const docs = await storage.getDocuments(a.familyId, a.profileId, section);
      // Strip fileData (base64) from list view — only return objectPath
      const stripped = docs.map(({ fileData, ...rest }) => rest);
      res.json(stripped);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.get("/api/documents/:id/file", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const doc = await storage.getDocumentById(req.params.id, a.familyId);
      if (!doc) return res.status(404).json({ message: "Non trovato" });
      if (doc.isPrivate && doc.profileId !== a.profileId) return res.status(403).json({ message: "Documento privato" });

      // New: serve from object storage
      if (doc.objectPath) {
        try {
          const file = await objStore.getObjectEntityFile(doc.objectPath);
          return await objStore.downloadObject(file, res);
        } catch (e) {
          if (!(e instanceof ObjectNotFoundError)) throw e;
        }
      }
      // Legacy: serve from base64
      if (!doc.fileData) return res.status(404).json({ message: "Nessun file" });
      const buf = Buffer.from(doc.fileData, "base64");
      res.setHeader("Content-Type", doc.mimeType || "application/octet-stream");
      res.setHeader("Content-Disposition", `inline; filename="${doc.fileName || "document"}"`);
      res.send(buf);
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.post("/api/documents", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { title, category, section, profileId, notes, isPrivate, expiresAt, fileName, mimeType, fileData, fileSize, objectPath } = req.body;
      if (!title || !category || !section) return res.status(400).json({ message: "Campi obbligatori mancanti" });
      // Fix #14: Prefer object storage; deprecate base64 for new uploads
      if (fileData && !objectPath) {
        console.warn("[Documents] Legacy base64 upload — use /api/documents/upload-url + objectPath instead");
        const sizeBytes = Buffer.from(fileData, "base64").length;
        if (sizeBytes > 4 * 1024 * 1024) return res.status(413).json({ message: "File base64 troppo grande (max 4MB). Usa upload diretto." });
      }
      const doc = await storage.createDocument({
        familyId: a.familyId,
        profileId: profileId || null,
        section,
        category,
        title,
        notes: notes || null,
        isPrivate: !!isPrivate,
        expiresAt: expiresAt ? new Date(expiresAt) : null,
        fileName: fileName || null,
        mimeType: mimeType || null,
        fileData: fileData || null,
        objectPath: objectPath || null,
        fileSize: fileSize || null,
      });
      res.json({ ...doc, fileData: undefined });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.patch("/api/documents/:id", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { title, notes, isPrivate, expiresAt, category } = req.body;
      const doc = await storage.updateDocument(req.params.id, a.familyId, {
        ...(title !== undefined && { title }),
        ...(notes !== undefined && { notes }),
        ...(isPrivate !== undefined && { isPrivate }),
        ...(expiresAt !== undefined && { expiresAt: expiresAt ? new Date(expiresAt) : null }),
        ...(category !== undefined && { category }),
      });
      if (!doc) return res.status(404).json({ message: "Non trovato" });
      res.json({ ...doc, fileData: undefined });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  app.delete("/api/documents/:id", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      await storage.deleteDocument(req.params.id, a.familyId);
      res.json({ ok: true });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  // ─── Weather Proxy (Fix #41: avoid exposing user GPS to third-party APIs) ──
  app.get("/api/weather", async (req, res) => {
    const a = await auth(req, res); if (!a) return;
    try {
      const { lat, lng } = req.query;
      if (!lat || !lng) return res.status(400).json({ message: "lat and lng required" });
      const [meteoRes, geoRes] = await Promise.allSettled([
        fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&current=temperature_2m,apparent_temperature,wind_speed_10m,weather_code,relative_humidity_2m&daily=weather_code,temperature_2m_max,temperature_2m_min&forecast_days=4&timezone=auto`),
        fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=10`, {
          headers: { "User-Agent": "FamilyTracker/1.0 (family-app)" },
        }),
      ]);
      const meteo = meteoRes.status === "fulfilled" ? await meteoRes.value.json() : {};
      const geo = geoRes.status === "fulfilled" ? await geoRes.value.json() : {};
      res.json({ meteo, geo });
    } catch (e: any) { res.status(500).json({ message: e.message }); }
  });

  return httpServer;
}
