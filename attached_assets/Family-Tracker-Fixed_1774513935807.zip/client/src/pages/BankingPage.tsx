import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import {
  Landmark, Trash2, RefreshCw, TrendingDown, TrendingUp,
  CreditCard, CheckCircle2, PlusCircle, Download, Euro,
  ArrowRight, Link2,
} from "lucide-react";
import { format, parseISO } from "date-fns";
import { it } from "date-fns/locale";
import type { BankConnection } from "@shared/schema";

type SafeConn = Omit<BankConnection, "accessToken" | "refreshToken">;

interface BankStatus {
  configured: boolean;
  environment: string;
  redirectUri: string | null;
  needsManualPaste: boolean;
}

interface AccountBalance {
  accountId: string;
  connectionId: string;
  institutionName: string;
  institutionLogo: string | null;
  iban: string | null;
  name: string | null;
  amount: number | null;
  currency: string;
}

interface BankTransaction {
  id: string;
  accountId: string;
  connectionId: string;
  institutionName: string;
  institutionLogo: string | null;
  amount: number;
  currency: string;
  description: string;
  counterparty: string | null;
  date: string;
}

function maskIban(iban: string | null) {
  if (!iban) return null;
  return iban.slice(0, 4) + " ···· ···· " + iban.slice(-4);
}

function parseCallbackUrl(raw: string): { code: string; state: string } | null {
  try {
    const url = new URL(raw.trim());
    const code = url.searchParams.get("code");
    const state = url.searchParams.get("state");
    if (code && state) return { code, state };
  } catch {}
  return null;
}

export default function BankingPage() {
  const { toast } = useToast();
  const callbackCalledRef = useRef(false);
  const prevLinkedCount = useRef(0);
  const [callbackPaste, setCallbackPaste] = useState("");

  const { data: status } = useQuery<BankStatus>({ queryKey: ["/api/banking/status"] });

  const { data: connections, isLoading: loadingConns } = useQuery<SafeConn[]>({
    queryKey: ["/api/banking/connections"],
    refetchInterval: (query) => {
      const data = query.state.data as SafeConn[] | undefined;
      return data?.some(c => c.status === "pending") ? 4000 : false;
    },
  });

  const linkedConns = connections?.filter(c => c.status === "linked") ?? [];
  const pendingConns = connections?.filter(c => c.status === "pending") ?? [];
  const hasLinked = linkedConns.length > 0;
  const hasPending = pendingConns.length > 0;

  const { data: balances, isLoading: loadingBal, refetch: refetchBal } = useQuery<AccountBalance[]>({
    queryKey: ["/api/banking/balances"],
    enabled: hasLinked,
    retry: false,
  });

  const { data: transactions, isLoading: loadingTx, refetch: refetchTx } = useQuery<BankTransaction[]>({
    queryKey: ["/api/banking/transactions"],
    enabled: hasLinked,
    retry: false,
  });

  // Notify on new linked connection
  useEffect(() => {
    const count = linkedConns.length;
    if (connections !== undefined && count > prevLinkedCount.current) {
      queryClient.invalidateQueries({ queryKey: ["/api/banking/balances"] });
      queryClient.invalidateQueries({ queryKey: ["/api/banking/transactions"] });
      if (prevLinkedCount.current >= 0) {
        toast({ title: "✅ Banca collegata!", description: "Il conto è stato collegato con successo." });
      }
    }
    prevLinkedCount.current = count;
  }, [linkedConns.length, connections]);

  // Auto-handle OAuth redirect (production mode: TrueLayer redirects back to this app)
  useEffect(() => {
    if (callbackCalledRef.current) return;
    if (status?.needsManualPaste) return; // In sandbox mode, user pastes manually
    const params = new URLSearchParams(window.location.search);
    const code = params.get("code");
    const state = params.get("state");
    const error = params.get("error");
    if (error) {
      toast({ title: "Autenticazione annullata", description: error, variant: "destructive" });
      const clean = new URL(window.location.href);
      clean.searchParams.delete("error");
      window.history.replaceState({}, "", clean.toString());
      return;
    }
    if (code && state) {
      callbackCalledRef.current = true;
      callbackMutation.mutate({ code, state });
    }
  }, [status]);

  const connectMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/banking/connect", {});
      return res.json(); // Fix #32: parse response JSON
    },
    onSuccess: (data: any) => {
      setCallbackPaste("");
      queryClient.invalidateQueries({ queryKey: ["/api/banking/connections"] });
      // In production: redirect directly to TrueLayer auth page (no manual paste needed)
      if (data?.authUrl && !status?.needsManualPaste) {
        window.location.href = data.authUrl;
      }
    },
    onError: (e: any) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  const callbackMutation = useMutation({
    mutationFn: async ({ code, state }: { code: string; state: string }) => {
      const res = await apiRequest("POST", "/api/banking/callback", { code, state });
      return res.json(); // Fix #32: parse response JSON
    },
    onSuccess: (data: any) => {
      setCallbackPaste("");
      queryClient.invalidateQueries({ queryKey: ["/api/banking/connections"] });
      queryClient.invalidateQueries({ queryKey: ["/api/banking/balances"] });
      queryClient.invalidateQueries({ queryKey: ["/api/banking/transactions"] });
      toast({
        title: "✅ Banca collegata!",
        description: `${data.institutionName} — ${data.accountCount} conto/i importato/i.`,
      });
      // Clean up URL params if present
      const clean = new URL(window.location.href);
      ["code", "state", "scope", "error"].forEach(p => clean.searchParams.delete(p));
      window.history.replaceState({}, "", clean.toString());
    },
    onError: (e: any) => toast({ title: "Errore collegamento", description: e.message, variant: "destructive" }),
  });

  const disconnectMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/banking/connections/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/banking/connections"] });
      queryClient.invalidateQueries({ queryKey: ["/api/banking/balances"] });
      queryClient.invalidateQueries({ queryKey: ["/api/banking/transactions"] });
      toast({ title: "Banca scollegata" });
    },
  });

  const importMutation = useMutation({
    mutationFn: (tx: BankTransaction) =>
      apiRequest("POST", "/api/budget/expenses", {
        title: tx.description,
        amount: Math.abs(tx.amount),
        date: tx.date,
        notes: tx.counterparty ? `Da: ${tx.counterparty}` : undefined,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/budget/expenses"] });
      toast({ title: "Importato nel Budget" });
    },
    onError: (e: any) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  function handleSubmitCallback() {
    const parsed = parseCallbackUrl(callbackPaste);
    if (!parsed) {
      toast({
        title: "URL non valido",
        description: "Copia l'URL completo dalla barra del browser dopo il login.",
        variant: "destructive",
      });
      return;
    }
    callbackMutation.mutate(parsed);
  }

  const totalBalance = balances?.reduce((s, b) => s + (b.amount ?? 0), 0) ?? 0;

  if (!status) {
    return (
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {[1, 2, 3].map(i => <Skeleton key={i} className="h-24 w-full rounded-2xl" />)}
      </div>
    );
  }

  if (!status.configured) {
    return (
      <div className="flex-1 overflow-y-auto p-4">
        <div className="rounded-2xl border border-border bg-muted/30 p-6 text-center space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center mx-auto">
            <Landmark className="w-8 h-8 text-amber-600" />
          </div>
          <div>
            <h3 className="font-semibold text-base mb-1">Configurazione richiesta</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Per collegare il conto bancario è necessario configurare le credenziali TrueLayer (Open Banking PSD2 europeo).
            </p>
          </div>
          <div className="text-left bg-background rounded-xl border border-border p-4 space-y-2">
            <ol className="text-sm space-y-2">
              <li className="flex gap-2"><span className="font-bold text-primary">1.</span><span>Registrati su <strong>truelayer.com</strong></span></li>
              <li className="flex gap-2"><span className="font-bold text-primary">2.</span><span>Crea un'app → copia il <strong>Client ID</strong> e <strong>Client Secret</strong></span></li>
              <li className="flex gap-2"><span className="font-bold text-primary">3.</span><span>Aggiungi <code>TRUELAYER_CLIENT_ID</code>, <code>TRUELAYER_CLIENT_SECRET</code> e <code>TRUELAYER_REDIRECT_URI</code> ai secret dell'app</span></li>
            </ol>
          </div>
          <p className="text-xs text-muted-foreground">🔒 Sola lettura · Standard europeo Open Banking PSD2</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto">
      <div className="p-4 space-y-4">

        {/* Callback processing spinner (auto-redirect in production) */}
        {callbackMutation.isPending && (
          <div className="rounded-2xl bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 p-4 flex items-center gap-3">
            <RefreshCw className="w-5 h-5 text-blue-600 animate-spin flex-shrink-0" />
            <p className="text-sm text-blue-700 dark:text-blue-300 font-medium">Collegamento banca in corso…</p>
          </div>
        )}

        {/* Total balance hero */}
        {hasLinked && (
          <div className="rounded-2xl bg-gradient-to-br from-primary to-primary/80 text-white p-5 space-y-1">
            <p className="text-xs font-medium opacity-70 uppercase tracking-wide">Saldo totale</p>
            {loadingBal ? (
              <Skeleton className="h-9 w-40 bg-white/20" />
            ) : (
              <p className="text-3xl font-bold">
                {totalBalance >= 0 ? "" : "−"} € {Math.abs(totalBalance).toLocaleString("it-IT", { minimumFractionDigits: 2 })}
              </p>
            )}
            <p className="text-xs opacity-60">
              {linkedConns.length} banca/banche · {balances?.length ?? 0} conto/i
              {status.environment === "sandbox" && " · SANDBOX"}
            </p>
          </div>
        )}

        {/* Pending connection card */}
        {pendingConns.map(conn => (
          <div key={conn.id} className="rounded-2xl border-2 border-primary/30 bg-primary/5 p-4 space-y-4">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <Link2 className="w-4 h-4 text-primary" />
                <p className="text-sm font-semibold">
                  {status.needsManualPaste ? "Collega il conto — 3 passi" : "Autorizza l'accesso bancario"}
                </p>
              </div>
              <button
                onClick={() => disconnectMutation.mutate(conn.id)}
                className="text-xs text-muted-foreground hover:text-destructive"
                data-testid={`button-cancel-${conn.id}`}
              >
                Annulla
              </button>
            </div>

            {status.needsManualPaste ? (
              /* ── SANDBOX: 3-step manual flow ── */
              <>
                {conn.authUrl && (
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-primary text-primary-foreground text-xs font-bold flex items-center justify-center flex-shrink-0">1</span>
                      <p className="text-xs font-medium">Copia questo link e aprilo in una nuova scheda del browser</p>
                    </div>
                    <textarea
                      readOnly value={conn.authUrl} rows={3}
                      onClick={(e) => (e.target as HTMLTextAreaElement).select()}
                      className="w-full text-xs font-mono bg-white dark:bg-black/30 border border-border rounded-lg p-2 resize-none text-foreground cursor-text"
                      data-testid="textarea-truelayer-url"
                    />
                    <p className="text-xs text-muted-foreground">Tocca per selezionare tutto · poi Ctrl+C · nuova scheda · incolla</p>
                  </div>
                )}
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-primary text-primary-foreground text-xs font-bold flex items-center justify-center flex-shrink-0">2</span>
                  <p className="text-xs font-medium">Accedi con: utente <strong>john</strong> · password <strong>doe</strong> → Mock Bank → conferma</p>
                </div>
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-primary text-primary-foreground text-xs font-bold flex items-center justify-center flex-shrink-0">3</span>
                    <p className="text-xs font-medium">Dopo il login, incolla qui l'URL completo dalla barra del browser</p>
                  </div>
                  <textarea
                    value={callbackPaste} onChange={(e) => setCallbackPaste(e.target.value)} rows={2}
                    placeholder="Incolla l'URL completo (inizia con https://console.truelayer.com/redirect-page?code=…)"
                    className="w-full text-xs font-mono bg-white dark:bg-black/30 border border-border rounded-lg p-2 resize-none text-foreground placeholder:text-muted-foreground"
                    data-testid="textarea-callback-url"
                  />
                  <Button size="sm" className="w-full gap-2" onClick={handleSubmitCallback}
                    disabled={!callbackPaste.trim() || callbackMutation.isPending} data-testid="button-submit-callback">
                    {callbackMutation.isPending
                      ? <><RefreshCw className="w-3.5 h-3.5 animate-spin" /> Collegamento in corso…</>
                      : <><ArrowRight className="w-3.5 h-3.5" /> Completa collegamento</>}
                  </Button>
                </div>
              </>
            ) : (
              /* ── PRODUCTION: auto-redirect ── */
              <div className="space-y-3">
                <div className="flex items-center gap-3 py-2">
                  <RefreshCw className="w-4 h-4 text-primary animate-spin flex-shrink-0" />
                  <div>
                    <p className="text-sm font-medium">Reindirizzamento in corso…</p>
                    <p className="text-xs text-muted-foreground">Stai per essere portato alla pagina di autorizzazione della tua banca</p>
                  </div>
                </div>
                {conn.authUrl && (
                  <Button size="sm" variant="outline" className="w-full gap-2" asChild>
                    <a href={conn.authUrl} data-testid="button-open-auth">
                      <ArrowRight className="w-3.5 h-3.5" /> Apri pagina bancaria manualmente
                    </a>
                  </Button>
                )}
              </div>
            )}
          </div>
        ))}

        {/* Account balances */}
        {balances && balances.length > 0 && (
          <div className="space-y-2">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Conti</p>
            {balances.map(b => (
              <div key={b.accountId} className="rounded-2xl border border-border bg-card p-4" data-testid={`account-card-${b.accountId}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {b.institutionLogo ? (
                      <img src={b.institutionLogo} alt={b.institutionName} className="w-10 h-10 rounded-lg object-contain bg-white border border-border p-1" />
                    ) : (
                      <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                        <CreditCard className="w-5 h-5 text-muted-foreground" />
                      </div>
                    )}
                    <div>
                      <p className="font-semibold text-sm">{b.name || b.institutionName}</p>
                      {b.iban && <p className="text-xs text-muted-foreground font-mono">{maskIban(b.iban)}</p>}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-base">
                      {b.amount != null ? `€ ${b.amount.toLocaleString("it-IT", { minimumFractionDigits: 2 })}` : "—"}
                    </p>
                    <p className="text-xs text-muted-foreground">{b.currency}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Transactions */}
        {hasLinked && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Movimenti recenti</p>
              <Button size="sm" variant="ghost" className="h-7 text-xs gap-1" onClick={() => { refetchBal(); refetchTx(); }} data-testid="button-refresh-transactions">
                <RefreshCw className="w-3 h-3" /> Aggiorna
              </Button>
            </div>
            {loadingTx ? (
              <div className="space-y-2">{[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-16 w-full rounded-xl" />)}</div>
            ) : !transactions?.length ? (
              <div className="text-center py-8 text-muted-foreground">
                <Euro className="w-8 h-8 mx-auto mb-2 opacity-30" />
                <p className="text-sm">Nessun movimento disponibile</p>
                <p className="text-xs mt-1">Premi Aggiorna per sincronizzare</p>
              </div>
            ) : (
              <div className="space-y-1.5">
                {transactions.slice(0, 50).map(tx => (
                  <div key={tx.id} className="rounded-xl border border-border bg-card p-3 flex items-center gap-3" data-testid={`transaction-${tx.id}`}>
                    <div className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 ${tx.amount < 0 ? "bg-red-100 dark:bg-red-950/40" : "bg-green-100 dark:bg-green-950/40"}`}>
                      {tx.amount < 0 ? <TrendingDown className="w-4 h-4 text-red-600 dark:text-red-400" /> : <TrendingUp className="w-4 h-4 text-green-600 dark:text-green-400" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{tx.description}</p>
                      <p className="text-xs text-muted-foreground">
                        {format(parseISO(tx.date), "d MMM yyyy", { locale: it })}
                        {tx.counterparty && ` · ${tx.counterparty}`}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <span className={`text-sm font-bold tabular-nums ${tx.amount < 0 ? "text-red-600 dark:text-red-400" : "text-green-600 dark:text-green-400"}`}>
                        {tx.amount < 0 ? "−" : "+"}€ {Math.abs(tx.amount).toFixed(2).replace(".", ",")}
                      </span>
                      {tx.amount < 0 && (
                        <button
                          onClick={() => importMutation.mutate(tx)}
                          disabled={importMutation.isPending}
                          className="p-1.5 rounded-lg hover:bg-accent transition-colors"
                          title="Importa nel Budget"
                          data-testid={`button-import-${tx.id}`}
                        >
                          <Download className="w-3.5 h-3.5 text-muted-foreground" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Empty state */}
        {!loadingConns && !hasLinked && !hasPending && !callbackMutation.isPending && (
          <div className="text-center py-12 space-y-4">
            <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto">
              <Landmark className="w-8 h-8 text-primary" />
            </div>
            <div>
              <p className="font-semibold">Nessun conto collegato</p>
              <p className="text-sm text-muted-foreground mt-1">Collega il tuo conto per vedere saldo e movimenti in tempo reale</p>
            </div>
          </div>
        )}

        {/* Connected banks list */}
        {hasLinked && (
          <div className="space-y-2">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Banche collegate</p>
            {linkedConns.map(conn => (
              <div key={conn.id} className="rounded-xl border border-border bg-card p-3 flex items-center justify-between" data-testid={`connection-${conn.id}`}>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-500" />
                  <span className="text-sm font-medium">{conn.institutionName}</span>
                  {conn.lastSyncAt && (
                    <span className="text-xs text-muted-foreground">· {format(new Date(conn.lastSyncAt), "d MMM", { locale: it })}</span>
                  )}
                </div>
                <button
                  onClick={() => disconnectMutation.mutate(conn.id)}
                  disabled={disconnectMutation.isPending}
                  className="p-1.5 rounded-lg hover:bg-destructive/10 transition-colors"
                  data-testid={`button-disconnect-${conn.id}`}
                >
                  <Trash2 className="w-4 h-4 text-destructive" />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Connect button */}
        <Button
          className="w-full gap-2"
          onClick={() => connectMutation.mutate()}
          disabled={connectMutation.isPending || callbackMutation.isPending}
          data-testid="button-connect-bank"
        >
          {connectMutation.isPending ? (
            <><RefreshCw className="w-4 h-4 animate-spin" /> Preparazione collegamento…</>
          ) : (
            <><PlusCircle className="w-4 h-4" /> {hasPending ? "Genera nuovo link" : "Collega conto bancario"}</>
          )}
        </Button>

        <p className="text-center text-xs text-muted-foreground pb-2">
          🔒 Sola lettura · Standard europeo Open Banking PSD2<br />
          Powered by TrueLayer · Le tue credenziali bancarie non vengono mai trattate dall'app
        </p>
      </div>
    </div>
  );
}
