import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Star, Plus, Trash2, CheckCircle, Award, Trophy, Clock } from "lucide-react";
import type { Task, Profile, Reward } from "@shared/schema";

type TaskWithProfile = Task & { assignedProfile: Profile };
type RewardWithProfile = Reward & { profile: Profile };

export default function TasksPage() {
  const { profile: myProfile } = useAuth();
  const { toast } = useToast();
  const [showAdd, setShowAdd] = useState(false);
  const [activeTab, setActiveTab] = useState<"tasks" | "rewards">("tasks");
  const [form, setForm] = useState({ assignedTo: "", title: "", description: "", points: 10 });

  const { data: members } = useQuery<Profile[]>({ queryKey: ["/api/family/members"] });
  const { data: tasks, isLoading } = useQuery<TaskWithProfile[]>({ queryKey: ["/api/tasks"] });
  const { data: rewards } = useQuery<RewardWithProfile[]>({ queryKey: ["/api/rewards"] });

  const isParent = myProfile?.role === "parent" || myProfile?.role === "guardian";

  const addMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/tasks", form);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      setShowAdd(false);
      setForm({ assignedTo: "", title: "", description: "", points: 10 });
      toast({ title: "Compito assegnato!" });
    },
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  const completeMutation = useMutation({
    mutationFn: async (id: string) => { await apiRequest("POST", `/api/tasks/${id}/complete`, {}); },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/tasks"] }); toast({ title: "✅ Compito completato! In attesa di verifica." }); },
  });

  const verifyMutation = useMutation({
    mutationFn: async (id: string) => { await apiRequest("POST", `/api/tasks/${id}/verify`, {}); },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/tasks"] }); queryClient.invalidateQueries({ queryKey: ["/api/rewards"] }); toast({ title: "⭐ Punti assegnati!" }); },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => { await apiRequest("DELETE", `/api/tasks/${id}`, undefined); },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/tasks"] }); },
  });

  const pendingTasks = tasks?.filter(t => !t.completedAt) || [];
  const completedTasks = tasks?.filter(t => t.completedAt && !t.verifiedBy) || [];
  const verifiedTasks = tasks?.filter(t => t.verifiedBy) || [];

  const myPoints = rewards?.find(r => r.profileId === myProfile?.id)?.pointsTotal || 0;

  return (
    <div className="flex flex-col h-full overflow-y-auto">
      <div className="p-4 space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold">Compiti & Premi</h2>
            <p className="text-xs text-muted-foreground">Guadagna punti completando compiti</p>
          </div>
          {isParent && (
            <Button size="sm" onClick={() => setShowAdd(!showAdd)} data-testid="button-add-task">
              <Plus className="w-4 h-4 mr-1" /> Compito
            </Button>
          )}
        </div>

        {/* My points card */}
        <div className="bg-gradient-to-br from-amber-400 to-orange-500 rounded-2xl p-4 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium opacity-90">I tuoi punti</p>
              <p className="text-3xl font-black">{myPoints}</p>
            </div>
            <Trophy className="w-12 h-12 opacity-25" />
          </div>
          <div className="mt-2 flex gap-2 flex-wrap">
            {rewards?.map(r => (
              <div key={r.profile.id} className="flex items-center gap-1.5 bg-white/20 rounded-full px-2 py-1">
                <div className="w-4 h-4 rounded-full" style={{ backgroundColor: r.profile.colorHex || "#fff" }} />
                <span className="text-xs font-semibold">{r.profile.name}: {r.pointsTotal}pt</span>
              </div>
            ))}
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 bg-muted rounded-lg p-1">
          <button onClick={() => setActiveTab("tasks")} className={`flex-1 text-xs py-1.5 rounded-md font-medium transition-colors ${activeTab === "tasks" ? "bg-background shadow text-foreground" : "text-muted-foreground"}`}>
            Compiti {pendingTasks.length > 0 && <span className="ml-1 bg-primary text-primary-foreground rounded-full px-1.5 text-xs">{pendingTasks.length}</span>}
          </button>
          <button onClick={() => setActiveTab("rewards")} className={`flex-1 text-xs py-1.5 rounded-md font-medium transition-colors ${activeTab === "rewards" ? "bg-background shadow text-foreground" : "text-muted-foreground"}`}>
            Classifica
          </button>
        </div>

        {/* Add task form */}
        {showAdd && isParent && (
          <div className="bg-accent/40 rounded-xl p-4 space-y-3">
            <h3 className="font-semibold text-sm">Nuovo compito</h3>
            <div>
              <Label className="text-xs">Assegna a</Label>
              <Select value={form.assignedTo} onValueChange={v => setForm({ ...form, assignedTo: v })}>
                <SelectTrigger data-testid="select-task-member"><SelectValue placeholder="Scegli membro" /></SelectTrigger>
                <SelectContent>
                  {members?.map(m => <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Titolo compito</Label>
              <Input placeholder="es. Riordina la camera, Porta fuori il cane" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} data-testid="input-task-title" />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label className="text-xs">Descrizione</Label>
                <Input placeholder="Dettagli…" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
              </div>
              <div>
                <Label className="text-xs">Punti premio</Label>
                <Select value={String(form.points)} onValueChange={v => setForm({ ...form, points: Number(v) })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {[5, 10, 15, 20, 30, 50].map(p => <SelectItem key={p} value={String(p)}>{p} pt</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex gap-2">
              <Button size="sm" className="flex-1" onClick={() => addMutation.mutate()} disabled={!form.assignedTo || !form.title || addMutation.isPending}>
                {addMutation.isPending ? "Salvataggio…" : "Assegna compito"}
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setShowAdd(false)}>Annulla</Button>
            </div>
          </div>
        )}

        {/* Content */}
        {isLoading ? (
          <div className="space-y-2">{[1,2,3].map(i => <Skeleton key={i} className="h-16 rounded-xl" />)}</div>
        ) : activeTab === "tasks" ? (
          <div className="space-y-4">
            {/* Pending tasks */}
            {pendingTasks.length > 0 && (
              <div>
                <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Da fare</h3>
                <div className="space-y-2">
                  {pendingTasks.map(t => (
                    <div key={t.id} className="p-3 rounded-xl border border-border bg-card" data-testid={`task-${t.id}`}>
                      <div className="flex items-start gap-3">
                        <div className="w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center text-sm font-bold text-white" style={{ backgroundColor: t.assignedProfile.colorHex || "#3B82F6" }}>
                          {t.assignedProfile.name.charAt(0)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-sm">{t.title}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <span className="text-xs text-muted-foreground">{t.assignedProfile.name}</span>
                            <Badge className="text-xs bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 border-0">
                              <Star className="w-3 h-3 mr-1" />{t.points} pt
                            </Badge>
                          </div>
                          {t.description && <p className="text-xs text-muted-foreground mt-1">{t.description}</p>}
                        </div>
                        <div className="flex items-center gap-1 flex-shrink-0">
                          {(t.assignedTo === myProfile?.id || isParent) && (
                            <button onClick={() => completeMutation.mutate(t.id)} className="p-1.5 rounded-lg bg-green-100 dark:bg-green-900/30 text-green-600 hover:bg-green-200" title="Segna come completato" data-testid={`complete-task-${t.id}`}>
                              <CheckCircle className="w-4 h-4" />
                            </button>
                          )}
                          {isParent && (
                            <button onClick={() => deleteMutation.mutate(t.id)} className="p-1.5 text-muted-foreground hover:text-destructive" data-testid={`delete-task-${t.id}`}>
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Awaiting verification */}
            {completedTasks.length > 0 && (
              <div>
                <h3 className="text-xs font-semibold text-amber-600 uppercase tracking-wide mb-2">⏳ In attesa di verifica</h3>
                <div className="space-y-2">
                  {completedTasks.map(t => (
                    <div key={t.id} className="p-3 rounded-xl border border-amber-200 bg-amber-50 dark:border-amber-800 dark:bg-amber-900/20" data-testid={`completed-task-${t.id}`}>
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center text-sm font-bold text-white opacity-70" style={{ backgroundColor: t.assignedProfile.colorHex || "#3B82F6" }}>
                          {t.assignedProfile.name.charAt(0)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-sm">{t.title}</p>
                          <p className="text-xs text-muted-foreground">{t.assignedProfile.name} • {t.points} pt</p>
                        </div>
                        {isParent && (
                          <Button size="sm" variant="default" className="bg-amber-500 hover:bg-amber-600 text-white flex-shrink-0" onClick={() => verifyMutation.mutate(t.id)} disabled={verifyMutation.isPending} data-testid={`verify-task-${t.id}`}>
                            <Award className="w-4 h-4 mr-1" /> Verifica
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Completed & verified */}
            {verifiedTasks.length > 0 && (
              <div>
                <h3 className="text-xs font-semibold text-green-600 uppercase tracking-wide mb-2">✅ Completati</h3>
                <div className="space-y-2">
                  {verifiedTasks.slice(0, 5).map(t => (
                    <div key={t.id} className="p-3 rounded-xl border border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-900/20 opacity-80" data-testid={`verified-task-${t.id}`}>
                      <div className="flex items-center gap-3">
                        <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                        <div className="flex-1">
                          <p className="text-sm line-through text-muted-foreground">{t.title}</p>
                          <p className="text-xs text-muted-foreground">{t.assignedProfile.name} • +{t.points} pt</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {pendingTasks.length === 0 && completedTasks.length === 0 && verifiedTasks.length === 0 && (
              <div className="text-center py-12 text-muted-foreground">
                <Star className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p className="font-medium text-sm">Nessun compito</p>
                <p className="text-xs mt-1">{isParent ? "Assegna compiti ai figli e guadagnate punti insieme" : "I tuoi genitori non hanno ancora assegnato compiti"}</p>
              </div>
            )}
          </div>
        ) : (
          /* Rewards leaderboard */
          <div className="space-y-3">
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Classifica punti</h3>
            {rewards && rewards.length > 0 ? (
              [...rewards].sort((a, b) => b.pointsTotal - a.pointsTotal).map((r, i) => (
                <div key={r.profileId} className={`p-4 rounded-xl border ${r.profileId === myProfile?.id ? "border-amber-300 bg-amber-50 dark:border-amber-700 dark:bg-amber-900/20" : "border-border bg-card"}`}>
                  <div className="flex items-center gap-3">
                    <span className="text-2xl font-black text-muted-foreground w-8 text-center">{i + 1}</span>
                    <div className="w-10 h-10 rounded-full flex items-center justify-center text-white text-base font-bold" style={{ backgroundColor: r.profile.colorHex || "#3B82F6" }}>
                      {r.profile.name.charAt(0)}
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold">{r.profile.name}</p>
                      <p className="text-xs text-muted-foreground capitalize">{r.profile.role}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xl font-black text-amber-500">{r.pointsTotal}</p>
                      <p className="text-xs text-muted-foreground">punti</p>
                    </div>
                  </div>
                  {r.pointsTotal > 0 && (
                    <div className="mt-2 h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-amber-400 rounded-full transition-all" style={{ width: `${Math.min(100, (r.pointsTotal / (Math.max(...rewards.map(x => x.pointsTotal)) || 1)) * 100)}%` }} />
                    </div>
                  )}
                </div>
              ))
            ) : (
              <div className="text-center py-10 text-muted-foreground">
                <Trophy className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p className="text-sm">Nessun punto ancora. Completa i compiti!</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
