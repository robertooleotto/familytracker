import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import { Calendar, ChevronLeft, ChevronRight, Plus, Clock, Trash2, Users } from "lucide-react";
import type { Event, Profile } from "@shared/schema";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay, addMonths, subMonths, isToday, parseISO } from "date-fns";

interface EventWithDetails extends Event {
  assignedProfiles?: Profile[];
}

export default function CalendarPage() {
  const { profile } = useAuth();
  const { toast } = useToast();
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [view, setView] = useState<"month" | "agenda">("month");

  const [form, setForm] = useState({
    title: "",
    description: "",
    startAt: "",
    endAt: "",
    color: "#3B82F6",
    reminderMin: 30,
    assignedTo: [] as string[],
  });

  const { data: events, isLoading } = useQuery<EventWithDetails[]>({
    queryKey: ["/api/events"],
    refetchInterval: 30000,
  });

  const { data: members } = useQuery<Profile[]>({
    queryKey: ["/api/family/members"],
  });

  const addMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/events", form);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
      setShowAddDialog(false);
      setForm({ title: "", description: "", startAt: "", endAt: "", color: "#3B82F6", reminderMin: 30, assignedTo: [] });
      toast({ title: "Event created!" });
    },
    onError: (e: Error) => toast({ title: "Failed", description: e.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/events/${id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
      toast({ title: "Event deleted" });
    },
    onError: (e: Error) => toast({ title: "Failed", description: e.message, variant: "destructive" }),
  });

  const days = eachDayOfInterval({ start: startOfMonth(currentMonth), end: endOfMonth(currentMonth) });
  const startDow = startOfMonth(currentMonth).getDay();

  const getEventsForDay = (day: Date) => {
    return events?.filter((e) => isSameDay(parseISO(String(e.startAt)), day)) || [];
  };

  const selectedDayEvents = getEventsForDay(selectedDate);
  const upcomingEvents = events
    ?.filter((e) => new Date(e.startAt) >= new Date())
    .sort((a, b) => new Date(a.startAt).getTime() - new Date(b.startAt).getTime())
    .slice(0, 20);

  const colorOptions = [
    { value: "#3B82F6", label: "Blue" },
    { value: "#10B981", label: "Green" },
    { value: "#F59E0B", label: "Amber" },
    { value: "#EF4444", label: "Red" },
    { value: "#8B5CF6", label: "Purple" },
    { value: "#EC4899", label: "Pink" },
  ];

  return (
    <div className="flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center gap-2">
          <button onClick={() => setView("month")} className={`text-xs px-3 py-1 rounded-full transition-colors ${view === "month" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-accent"}`}>
            Month
          </button>
          <button onClick={() => setView("agenda")} className={`text-xs px-3 py-1 rounded-full transition-colors ${view === "agenda" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-accent"}`}>
            Agenda
          </button>
        </div>
        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogTrigger asChild>
            <Button size="sm" data-testid="button-add-event">
              <Plus className="w-4 h-4 mr-1" />
              Add Event
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-sm">
            <DialogHeader>
              <DialogTitle>New Event</DialogTitle>
            </DialogHeader>
            <div className="space-y-3 mt-2">
              <div>
                <Label>Title</Label>
                <Input
                  placeholder="Soccer practice"
                  value={form.title}
                  onChange={(e) => setForm({ ...form, title: e.target.value })}
                  data-testid="input-event-title"
                />
              </div>
              <div>
                <Label>Description</Label>
                <Textarea
                  placeholder="Optional notes…"
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  rows={2}
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label>Start</Label>
                  <Input
                    type="datetime-local"
                    value={form.startAt}
                    onChange={(e) => setForm({ ...form, startAt: e.target.value })}
                    data-testid="input-event-start"
                  />
                </div>
                <div>
                  <Label>End</Label>
                  <Input
                    type="datetime-local"
                    value={form.endAt}
                    onChange={(e) => setForm({ ...form, endAt: e.target.value })}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label>Color</Label>
                  <Select value={form.color} onValueChange={(v) => setForm({ ...form, color: v })}>
                    <SelectTrigger>
                      <SelectValue>
                        <span className="flex items-center gap-2">
                          <span className="w-3 h-3 rounded-full" style={{ background: form.color }} />
                        </span>
                      </SelectValue>
                    </SelectTrigger>
                    <SelectContent>
                      {colorOptions.map((c) => (
                        <SelectItem key={c.value} value={c.value}>
                          <span className="flex items-center gap-2">
                            <span className="w-3 h-3 rounded-full" style={{ background: c.value }} />
                            {c.label}
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Reminder</Label>
                  <Select value={String(form.reminderMin)} onValueChange={(v) => setForm({ ...form, reminderMin: Number(v) })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0">None</SelectItem>
                      <SelectItem value="15">15 min</SelectItem>
                      <SelectItem value="30">30 min</SelectItem>
                      <SelectItem value="60">1 hour</SelectItem>
                      <SelectItem value="1440">1 day</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              {members && members.length > 0 && (
                <div>
                  <Label className="mb-2 block">Assign To</Label>
                  <div className="space-y-2">
                    {members.map((m) => (
                      <div key={m.id} className="flex items-center gap-2">
                        <Checkbox
                          id={`assign-${m.id}`}
                          checked={form.assignedTo.includes(m.id)}
                          onCheckedChange={(checked) => {
                            setForm({
                              ...form,
                              assignedTo: checked
                                ? [...form.assignedTo, m.id]
                                : form.assignedTo.filter((id) => id !== m.id),
                            });
                          }}
                        />
                        <div className="flex items-center gap-2">
                          <div className="w-5 h-5 rounded-full text-white text-xs flex items-center justify-center font-bold" style={{ backgroundColor: m.colorHex }}>
                            {m.name.charAt(0)}
                          </div>
                          <label htmlFor={`assign-${m.id}`} className="text-sm">{m.name}</label>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              <Button className="w-full" onClick={() => addMutation.mutate()} disabled={addMutation.isPending || !form.title || !form.startAt}>
                {addMutation.isPending ? "Creating…" : "Create Event"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex-1 overflow-y-auto">
        {view === "month" ? (
          <div className="p-4">
            {/* Month nav */}
            <div className="flex items-center justify-between mb-4">
              <button onClick={() => setCurrentMonth(subMonths(currentMonth, 1))} className="p-1 hover:bg-accent rounded-md">
                <ChevronLeft className="w-5 h-5" />
              </button>
              <h2 className="font-semibold text-base">{format(currentMonth, "MMMM yyyy")}</h2>
              <button onClick={() => setCurrentMonth(addMonths(currentMonth, 1))} className="p-1 hover:bg-accent rounded-md">
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>

            {/* Day headers */}
            <div className="grid grid-cols-7 mb-1">
              {["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"].map((d) => (
                <div key={d} className="text-center text-xs font-medium text-muted-foreground py-1">{d}</div>
              ))}
            </div>

            {/* Calendar grid */}
            <div className="grid grid-cols-7 gap-px bg-border rounded-lg overflow-hidden">
              {Array.from({ length: startDow }).map((_, i) => (
                <div key={`empty-${i}`} className="bg-background aspect-square" />
              ))}
              {days.map((day) => {
                const dayEvents = getEventsForDay(day);
                const isSelected = isSameDay(day, selectedDate);
                const todayDay = isToday(day);

                return (
                  <button
                    key={day.toString()}
                    onClick={() => setSelectedDate(day)}
                    className={`bg-background aspect-square flex flex-col items-center justify-start p-1 transition-colors hover:bg-accent/50 ${
                      isSelected ? "bg-accent" : ""
                    }`}
                    data-testid={`calendar-day-${format(day, "yyyy-MM-dd")}`}
                  >
                    <span className={`text-xs w-5 h-5 flex items-center justify-center rounded-full ${
                      todayDay ? "bg-primary text-primary-foreground font-bold" :
                      isSelected ? "bg-accent-foreground/10 font-semibold" :
                      "text-foreground"
                    }`}>
                      {format(day, "d")}
                    </span>
                    <div className="flex gap-0.5 flex-wrap justify-center mt-0.5">
                      {dayEvents.slice(0, 3).map((e) => (
                        <div
                          key={e.id}
                          className="w-1.5 h-1.5 rounded-full"
                          style={{ backgroundColor: e.color || "#3B82F6" }}
                        />
                      ))}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Selected day events */}
            <div className="mt-4">
              <h3 className="text-sm font-semibold mb-2 text-muted-foreground">
                {isToday(selectedDate) ? "Today" : format(selectedDate, "EEEE, MMM d")}
              </h3>
              {isLoading ? (
                <Skeleton className="h-16 rounded-lg" />
              ) : selectedDayEvents.length > 0 ? (
                <div className="space-y-2">
                  {selectedDayEvents.map((e) => (
                    <EventCard key={e.id} event={e} members={members || []} onDelete={() => deleteMutation.mutate(e.id)} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-6 text-muted-foreground text-sm">
                  <Calendar className="w-8 h-8 mx-auto mb-2 opacity-30" />
                  No events for this day
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="p-4 space-y-2">
            <h3 className="text-sm font-semibold text-muted-foreground mb-3">Upcoming Events</h3>
            {isLoading ? (
              <div className="space-y-2">
                {[1, 2, 3].map((i) => <Skeleton key={i} className="h-16 rounded-lg" />)}
              </div>
            ) : upcomingEvents && upcomingEvents.length > 0 ? (
              upcomingEvents.map((e) => (
                <EventCard key={e.id} event={e} members={members || []} onDelete={() => deleteMutation.mutate(e.id)} showDate />
              ))
            ) : (
              <div className="text-center py-12 text-muted-foreground">
                <Calendar className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p className="text-sm">No upcoming events</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function EventCard({ event, members, onDelete, showDate }: { event: EventWithDetails; members: Profile[]; onDelete: () => void; showDate?: boolean }) {
  const assignedProfiles = members.filter((m) => event.assignedTo?.includes(m.id));

  return (
    <div
      className="flex items-start gap-3 p-3 rounded-lg border border-card-border bg-card hover:bg-accent/20 transition-colors"
      data-testid={`event-${event.id}`}
    >
      <div className="w-1 self-stretch rounded-full flex-shrink-0 mt-1" style={{ backgroundColor: event.color || "#3B82F6" }} />
      <div className="flex-1 min-w-0">
        <p className="font-medium text-sm truncate">{event.title}</p>
        {showDate && (
          <p className="text-xs text-muted-foreground mt-0.5">
            {format(new Date(event.startAt), "EEE, MMM d")}
          </p>
        )}
        <div className="flex items-center gap-2 mt-1">
          <span className="flex items-center gap-1 text-xs text-muted-foreground">
            <Clock className="w-3 h-3" />
            {format(new Date(event.startAt), "h:mm a")}
            {event.endAt && ` – ${format(new Date(event.endAt), "h:mm a")}`}
          </span>
        </div>
        {assignedProfiles.length > 0 && (
          <div className="flex items-center gap-1 mt-1.5">
            <Users className="w-3 h-3 text-muted-foreground" />
            <div className="flex -space-x-1">
              {assignedProfiles.map((m) => (
                <div
                  key={m.id}
                  className="w-4 h-4 rounded-full border border-background text-white text-xs flex items-center justify-center font-bold"
                  style={{ backgroundColor: m.colorHex }}
                  title={m.name}
                >
                  {m.name.charAt(0)}
                </div>
              ))}
            </div>
          </div>
        )}
        {event.description && (
          <p className="text-xs text-muted-foreground mt-1 truncate">{event.description}</p>
        )}
      </div>
      <button
        onClick={onDelete}
        className="text-muted-foreground hover:text-destructive transition-colors p-1"
        data-testid={`delete-event-${event.id}`}
      >
        <Trash2 className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}
