# FamilyTracker

A privacy-first, mobile-first family coordination web app. Zero data brokering — inspired by Life360 but without selling user data.

---

## 🧠 MEMORIA PERSISTENTE — Aggiornare ad ogni sessione

> Questa sezione viene letta automaticamente all'inizio di ogni nuova conversazione. Contiene tutto ciò che abbiamo imparato insieme: famiglia reale, preferenze, abitudini, decisioni prese.

### La famiglia reale: Oleotto - Di Pascoli
- **Codice invito famiglia**: `1FC75712`
- **Lingua dell'app**: sempre italiano (UI, messaggi, toast, label)
- **L'utente principale** preferisce comunicare in italiano con l'AI
- L'app è pensata per uso quotidiano reale, non demo — ogni feature deve funzionare davvero

### Preferenze di sviluppo apprese
- **Mobile-first è priorità assoluta**: l'utente usa l'app dal telefono, non dal desktop
- **GPS mobile era rotto**: gli errori venivano ignorati silenziosamente — ora abbiamo gestione completa con banner, fallback e istruzioni in italiano
- **Registrazione**: l'utente voleva Nome + Cognome + Email (non username tecnico) — implementato con auto-generazione username dall'email
- **Login**: accetta email o username (retrocompatibile con account demo esistenti)
- **Non duplicare campi**: es. non chiedere sia username che email — scegliere l'approccio più semplice per l'utente finale
- **Evitare silent failures**: ogni errore deve mostrare un messaggio utile in italiano

### Decisioni architetturali prese
- **Object Storage (GCS)**: i file (documenti, foto mood) vengono caricati direttamente con presigned URL, non base64 — limite 50MB
- **Base64 legacy**: ancora supportato per backward compatibility, ma i nuovi upload usano objectPath
- **Claude API**: modello `claude-opus-4-5`, chiamato lato server — chiave in `CLAUDE_API_KEY`
- **DB body limit**: 15MB in `server/index.ts` (per immagini base64 inviate a Claude da Cucina AI)
- **Drizzle ORM**: push schema con `npm run db:push`; se serve conferma interattiva, eseguire SQL diretto
- **TanStack Query v5**: solo forma oggetto `useQuery({ queryKey: [...] })`, no `onSuccess` nelle query options

### Funzionalità implementate (stato attuale)
- ✅ Auth (register/login/join) con email + cognome
- ✅ Mappa live con GPS corretto su mobile (gestione permessi, errori, fallback)
- ✅ Chat famiglia
- ✅ Calendario eventi
- ✅ Lista spesa
- ✅ Budget & spese
- ✅ Farmaci
- ✅ Scadenze casa
- ✅ Compiti & Premi (gamification bimbi)
- ✅ Zone sicure (geofence)
- ✅ Animali domestici + storico medico
- ✅ Veicoli + scadenze assicurazione/revisione
- ✅ Abbonamenti
- ✅ Contatti casa
- ✅ Compleanni & Anniversari
- ✅ Chi cucina stasera
- ✅ Cucina AI (ricette da foto ingredienti)
- ✅ Documenti (upload su cloud, max 50MB)
- ✅ Registri scuola (ClasseViva / Argo)
- ✅ Protezione smart (modalità scuola, anziani, zone sicure)
- ✅ Open Banking (TrueLayer PSD2 — credenziali in Secrets)
- ✅ AI Predittiva (briefing, anomalie, sommario serale)
- ✅ Onboarding wizard 8 passi con profilo famiglia personalizzato
- ✅ Object Storage integrato (presigned URL upload)

### Cose da ricordare per sessioni future
- Il seed di dati demo usa la famiglia "Johnson" — la famiglia reale è "Oleotto - Di Pascoli" con codice `1FC75712`
- Le credenziali demo esistenti (sarah/mike/emma con password demo123) rimangono valide
- Il login accetta sia email che username per retrocompatibilità
- `replit.md` va sempre aggiornato quando si aggiungono nuove feature o si prendono decisioni importanti

---

## Architecture

- **Frontend**: React 18 + Vite + TypeScript, Tailwind CSS, TanStack Query, wouter routing
- **Backend**: Express.js + TypeScript, JWT auth (jsonwebtoken, localStorage)
- **Database**: PostgreSQL via Drizzle ORM
- **Maps**: Leaflet.js (dynamically imported)
- **Weather**: Open-Meteo API (free, no API key needed)

## Key Features (v2.0)

### Core MVP
1. **Auth** — Register family, join via invite code, login
2. **Live Map** — Adaptive GPS polling (30s moving / 5min stationary), location pause, SOS button
3. **Family Chat** — 3s polling, read receipts
4. **Calendar** — Monthly + agenda views, CRUD events
5. **Shopping List** — Categorized items, real-time sync

### Sprint 3 (v3.0)
14. **Budget Spese** — Monthly expense planning: budget categories with progress bars, per-expense tracking, month navigation, spending summary card. Tables: `budget_categories`, `expenses`.
15. **Animali domestici** — Pet profiles + medical history (vaccinations, deworming, checkups, grooming). Tables: `pets`, `pet_events`. Routes: `/api/pets`, `/api/pets/events`.
16. **Veicoli di famiglia** — Vehicle profiles with expiry alerts (insurance/revision/bollo color-coded chips), fuel/maintenance logs. Tables: `vehicles`, `vehicle_logs`. Routes: `/api/vehicles`, `/api/vehicles/logs`.
17. **Abbonamenti** — Subscription tracker with monthly cost summary, active/suspended toggle, renewal dates. Table: `subscriptions`. Route: `/api/subscriptions`.
18. **Contatti casa** — Home contacts directory grouped by category (plumber, electrician, doctor, etc.), search bar, tap-to-call. Table: `home_contacts`. Route: `/api/home-contacts`.
19. **Compleanni & Anniversari** — Rolling calendar of birthdays/anniversaries with countdown badges and upcoming section. Table: `anniversaries`. Route: `/api/anniversaries`.
20. **Chi cucina stasera** — Weekly dinner rotation grid with assigned family members and meal description. Table: `dinner_rotation`. Route: `/api/dinner-rotation`.
Navigation: "Altro" sheet reorganized into 4 sections (Casa & Famiglia, Animali & Veicoli, Servizi & Ricorrenze, Altro).

### Sprint 4 (v4.0)
21. **Conto bancario (Open Banking)** — TrueLayer PSD2 OAuth2 integration. Read-only bank account linking via OAuth2 redirect flow, real balance display, transaction history, one-click import to Budget. Tables: `bank_connections`. Routes: `/api/banking/status`, `/api/banking/connect`, `/api/banking/callback`, `/api/banking/connections`, `/api/banking/balances`, `/api/banking/transactions`. Env vars: `TRUELAYER_CLIENT_ID`, `TRUELAYER_CLIENT_SECRET`, `TRUELAYER_ENVIRONMENT=sandbox`, `TRUELAYER_REDIRECT_URI` (optional — set to the deployed app URL for automatic OAuth redirect; if absent, uses `https://console.truelayer.com/redirect-page` and prompts user to paste the callback URL manually). Server module: `server/truelayer.ts`. Tokens are never exposed to the frontend. `needsManualPaste` flag in status API controls which flow the frontend shows.

### Sprint 2 (v2.0)
6. **Zone sicure (Geofence)** — Custom zones on map, debounce 3min (zero false alerts), enter/exit alerts
7. **Farmaci & Salute** — Medication tracking, schedules, taken confirmation
8. **Scadenze Casa** — Home deadlines (bollo, assicurazione, manutenzione), urgency indicators
9. **Compiti & Premi** — Gamified tasks for kids, points, leaderboard, parent verification
10. **Pausa posizione** — Privacy: any adult can pause their location sharing
11. **Meteo** — Real-time weather widget on dashboard via Open-Meteo
12. **Modalità interfaccia** — Full / Simple / Elderly modes per profile
13. **Settings** — Profile editing, color picker, privacy controls

### Privacy (non-negotiable)
- Zero third-party analytics
- Location data retention: 30 days max
- Each member can pause their location at any time
- No data brokering

## Demo Credentials

- Username: `sarah` / `mike` / `emma`, Password: `demo123`
- Invite code: `DEMO1234`

## Navigation

**Bottom nav** (5 tabs): Home, Mappa, Chat, Agenda, Altro
**"Altro" sheet** (slide-up): Lista spesa, Compiti, Scadenze casa, Farmaci, Zone sicure, Impostazioni

## Project Structure

```
client/src/
  pages/
    AuthPage.tsx          # Login / Register / Join family
    DashboardPage.tsx     # Weather + stats + family overview
    MapPage.tsx           # Live map + adaptive GPS + pause + SOS
    ChatPage.tsx          # Family chat
    CalendarPage.tsx      # Calendar events
    ShoppingPage.tsx      # Shopping list
    GeofencePage.tsx      # Geofence zones (new v2)
    MedsPage.tsx          # Medications (new v2)
    HomeDeadlinesPage.tsx # Home deadlines (new v2)
    TasksPage.tsx         # Tasks & rewards (new v2)
    SettingsPage.tsx      # Profile + privacy + UI mode (new v2)
  hooks/
    useAuth.ts            # Session management
  lib/
    queryClient.ts        # TanStack Query + auth headers
    auth.ts               # localStorage session

server/
  index.ts      # Express entry, seed on startup
  routes.ts     # All API routes
  storage.ts    # DbStorage class (Drizzle ORM)
  db.ts         # Drizzle + pg Pool
  seed.ts       # Demo data seeder (idempotent)

shared/
  schema.ts     # All Drizzle tables + types
```

## API Routes

```
POST /api/auth/register|login|join
GET  /api/family
GET  /api/family/members
PATCH /api/profile
POST /api/location/pause|resume
POST /api/locations              # Update own position
GET  /api/family/locations       # All member locations
POST /api/sos
GET/POST/DELETE /api/geofences/:id
GET/POST/DELETE /api/events/:id
GET/POST /api/messages, POST /api/messages/:id/read
GET/POST/PATCH/DELETE /api/shopping
DELETE /api/shopping/checked/all
GET/POST/DELETE /api/medications, POST /api/medications/:id/taken
GET/POST/PATCH/DELETE /api/deadlines/:id
GET/POST/DELETE /api/tasks/:id
POST /api/tasks/:id/complete|verify
GET /api/rewards
GET/POST /api/checkins
```

## Adaptive GPS Polling

When tracking is started:
- Uses `navigator.geolocation.watchPosition`
- Calculates speed + distance from last position
- Moving (>0.5 m/s or >20m displacement): uploads every 30s
- Stationary: uploads every 5 min
- Badge on map shows current interval
